import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Absolute base for Netlify (deep links like /services/ keep working). Set VITE_BASE=./ for a folder-portable build.
export default defineConfig({
  base: process.env.VITE_BASE || '/',
  plugins: [react()],
  server: { host: true, port: 5173 },
  build: {
    target: 'es2020',
    chunkSizeWarningLimit: 1200,
    rollupOptions: {
      output: {
        manualChunks: {
          three: ['three'],
          r3f: ['@react-three/fiber', '@react-three/drei'],
          gsap: ['gsap', '@gsap/react'],
        },
      },
    },
  },
});
