# Markov Auto — cinematic React build

React 19 + TypeScript + Vite, React Router, GSAP/ScrollTrigger, Motion, Three.js via React Three Fiber + drei.
The original static site is untouched; a reference copy of its pages lives in `reference/original-site/`.

## Run it
```
npm install
npm run dev          # http://localhost:5173
```
Windows PowerShell: use `npm.cmd install` and `npm.cmd run dev` if `npm` is blocked.

Production check: `npm run build` then `npm run preview` (http://localhost:4173).

Useful URL switches (any page): `?nointro` skip the intro · `?quality=low|high` force the light/heavy 3D path · `?debug` exposes the 3D camera on `window` for testing.

## What's where
| | |
|---|---|
| `src/components/Intro.tsx` | Cinematic intro (full first visit, ~1.5s for returning visitors, skipped for reduced motion). Drives the 3D light level + camera dolly. |
| `src/components/ScrollStory.tsx` | Home: sticky 3D scene; ScrollTrigger progress drives car rotation, camera path, x-ray and part highlights through 7 chapters. |
| `src/three/CarModel.tsx` | **Procedural demonstration car** built in code (not a model of any real car). Highlightable engine, turbo, brakes, suspension, ECU, exhaust. |
| `src/three/storyPath.ts` | Camera/car keyframes per chapter. Tweak framing here. |
| `src/three/ExplorerCanvas.tsx` | Services: orbit (drag / pinch / zoom buttons), numbered hotspots, animated camera focus. |
| `src/components/Page.tsx` | Route transition wipe (red + charcoal columns). |
| `src/data/site.ts` | All business copy, verbatim from the original site. |

## Contact form
Wired for **Netlify Forms** (form name `service-request`; a hidden static copy in `index.html` lets Netlify detect it).
It only sends on a real deployment. On localhost it clearly says nothing was sent. Turn on email notifications in Netlify → Forms.

## Swapping in a real 3D model later
Replace `<CarModel />` in `StoryCanvas.tsx` / `ExplorerCanvas.tsx` with a licensed, Draco-compressed GLB loaded via drei's `useGLTF`, and remap the highlight groups.
