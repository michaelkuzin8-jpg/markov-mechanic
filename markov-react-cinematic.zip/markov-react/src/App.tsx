import { BrowserRouter, HashRouter, Route, Routes, useLocation } from 'react-router';
import { AnimatePresence } from 'motion/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Intro from './components/Intro';
import Nav from './components/Nav';
import Page from './components/Page';
import MobileCTA from './components/MobileCTA';
import Home from './pages/Home';
import Services from './pages/Services';
import Workshop from './pages/Workshop';
import Work from './pages/Work';
import Contact from './pages/Contact';
import NotFound from './pages/NotFound';

// Hash routing is only used for the static preview build (no server-side rewrites there).
const Router = import.meta.env.VITE_HASH_ROUTER === '1' ? HashRouter : BrowserRouter;

function Shell() {
  const location = useLocation();
  return (
    <>
      <Intro />
      <Nav />
      <AnimatePresence
        mode="wait"
        initial={false}
        onExitComplete={() => {
          window.scrollTo(0, 0);
          requestAnimationFrame(() => ScrollTrigger.refresh());
        }}
      >
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<Page title="Home"><Home /></Page>} />
          <Route path="/services" element={<Page title="Services"><Services /></Page>} />
          <Route path="/workshop" element={<Page title="Workshop"><Workshop /></Page>} />
          <Route path="/work" element={<Page title="Work"><Work /></Page>} />
          <Route path="/contact" element={<Page title="Contact"><Contact /></Page>} />
          <Route path="*" element={<Page title="Not Found"><NotFound /></Page>} />
        </Routes>
      </AnimatePresence>
      <MobileCTA />
    </>
  );
}

export default function App() {
  return (
    <Router>
      <Shell />
    </Router>
  );
}
