import { useEffect, useState, useSyncExternalStore } from 'react';
import SIZES from '../data/images.json';

function mediaStore(query: string) {
  return {
    subscribe(cb: () => void) {
      if (typeof window === 'undefined') return () => {};
      const mq = window.matchMedia(query);
      mq.addEventListener('change', cb);
      return () => mq.removeEventListener('change', cb);
    },
    get() {
      return typeof window !== 'undefined' && window.matchMedia(query).matches;
    },
  };
}

const reduced = mediaStore('(prefers-reduced-motion: reduce)');
const small = mediaStore('(max-width: 820px)');
const coarse = mediaStore('(pointer: coarse)');

export const useReducedMotion = () => useSyncExternalStore(reduced.subscribe, reduced.get, () => false);
export const useIsMobile = () => useSyncExternalStore(small.subscribe, small.get, () => false);
export const useIsTouch = () => useSyncExternalStore(coarse.subscribe, coarse.get, () => false);

export const prefersReducedMotion = () => reduced.get();

/** Rough GPU budget: phones and low-core devices get the lighter 3D path. */
export function useLowPower() {
  const mobile = useIsMobile();
  const touch = useIsTouch();
  const cores = typeof navigator !== 'undefined' ? navigator.hardwareConcurrency || 4 : 8;
  const q = typeof location !== 'undefined' ? new URLSearchParams(location.search).get('quality') : null;
  if (q === 'low') return true;
  if (q === 'high') return false;
  return mobile || touch || cores <= 4;
}

/** True once the element has come within `margin` of the viewport (used to lazy-mount 3D). */
export function useNearViewport<T extends Element>(ref: React.RefObject<T | null>, margin = '200px', once = true) {
  const [near, setNear] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setNear(true);
          if (once) io.disconnect();
        } else if (!once) setNear(false);
      },
      { rootMargin: margin },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [ref, margin, once]);
  return near;
}

export const imgSrc = (name: string) => `${import.meta.env.BASE_URL}images/${name}.webp`;
export const imgSize = (name: string) => (SIZES as Record<string, number[]>)[name] ?? [1448, 1086];
export const imgSet = (name: string) =>
  `${import.meta.env.BASE_URL}images/${name}-800.webp 800w, ${import.meta.env.BASE_URL}images/${name}.webp ${imgSize(name)[0]}w`;
