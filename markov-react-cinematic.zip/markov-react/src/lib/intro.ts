import { useSyncExternalStore } from 'react';
import { prefersReducedMotion } from './hooks';

/**
 * Intro state shared by the DOM intro overlay and the 3D scene.
 *  - light: 0..1 scene light level (the "lighting reveal")
 *  - cam:   0..1 camera dolly from the intro close-up to the hero framing
 */
type Mode = 'full' | 'short' | 'none';
const SEEN_KEY = 'markov-intro-seen';

function readSeen() {
  try { return localStorage.getItem(SEEN_KEY) === '1'; } catch { return false; }
}

const mode: Mode = typeof window === 'undefined' || prefersReducedMotion() || /[?&]nointro\b/.test(location.search)
  ? 'none'
  : readSeen() ? 'short' : 'full';

export const intro = {
  mode,
  light: mode === 'none' ? 1 : 0,
  cam: mode === 'none' ? 1 : 0,
  done: mode === 'none',
};

const listeners = new Set<() => void>();
export function finishIntro() {
  if (intro.done) return;
  intro.done = true;
  intro.light = 1;
  intro.cam = 1;
  try { localStorage.setItem(SEEN_KEY, '1'); } catch { /* storage unavailable: intro simply plays again */ }
  listeners.forEach((l) => l());
}

export const useIntroDone = () =>
  useSyncExternalStore((cb) => { listeners.add(cb); return () => listeners.delete(cb); }, () => intro.done, () => true);
