// Business content carried over verbatim from the original Markov Auto site (reference/original-site).
// Nothing here is invented: no phone number, street address, prices, reviews or credentials exist in the source.

export const BUSINESS = {
  name: 'Markov Auto',
  location: 'Springfield, Virginia',
  tagline: 'Enthusiast Cars Only. Real Work Done Here.',
  summary: 'Maintenance, diagnostics, repairs, and performance work.',
  footer: 'Mechanical work done in-house.',
} as const;

export type ServiceKey = 'maintenance' | 'diagnostics' | 'brakes' | 'turbo' | 'performance';

export interface Service {
  key: ServiceKey;
  title: string;
  formValue: string; // matches the contact form "Type of Work" option
  text: string; // verbatim from services.html
  short: string;
  image: string;
  imageAlt: string;
  parts: string; // what the 3D demo highlights for this service
}

export const SERVICES: Service[] = [
  {
    key: 'maintenance',
    title: 'Maintenance',
    formValue: 'Regular Maintenance',
    text: 'Regular maintenance keeps your car reliable. Most cars should be checked around every 10,000 miles. Performance-driven or modified cars may need service every 3,000 to 5,000 miles.',
    short: 'Reliability, on schedule.',
    image: 'miata-garage',
    imageAlt: 'Blue Mazda Miata parked inside the workshop',
    parts: 'Engine, oil and fluids',
  },
  {
    key: 'diagnostics',
    title: 'Diagnostics',
    formValue: 'Diagnostics',
    text: 'If your car has a no-start, boost leak, overheating, a misfire, unusual noises, or electrical problems, bring it in immediately. We offer diagnostics and maintenance in-house.',
    short: 'Find the fault. Fix the fault.',
    image: 'miata-turbo-hood',
    imageAlt: 'Mazda Miata with the hood open, engine exposed',
    parts: 'ECU and wiring',
  },
  {
    key: 'brakes',
    title: 'Brakes + Suspension',
    formValue: 'Brakes or Suspension',
    text: 'We handle brake jobs, pads, rotors, fluid, coilovers, bushings, control arms, alignment preparation, and other brake or suspension service your car may need.',
    short: 'Stop hard. Corner flat.',
    image: 'porsche-cayman',
    imageAlt: 'Red Porsche Cayman S',
    parts: 'Rotors, calipers, coilovers and control arms',
  },
  {
    key: 'turbo',
    title: 'Turbo Systems',
    formValue: 'Turbo System',
    text: 'We work on custom turbo systems, intercooler piping, intake routing, oil and coolant lines, clamps, and heat management to help your setup make reliable power.',
    short: 'Boost, built to last.',
    image: 'miata-engine-bay',
    imageAlt: 'Turbocharged Mazda Miata engine bay with copper valve cover',
    parts: 'Turbocharger and charge piping',
  },
  {
    key: 'performance',
    title: 'Performance Installs',
    formValue: 'Performance Install',
    text: 'We install performance parts, supporting parts, intake and exhaust components, suspension upgrades, cooling upgrades, and other parts for your build.',
    short: 'Parts in. Done right.',
    image: 'audi-a5',
    imageAlt: 'White Audi A5 coupe at night',
    parts: 'Intercooler, intake and exhaust',
  },
];

export const FORM_SERVICES = ['Regular Maintenance', 'Diagnostics', 'Brakes or Suspension', 'Turbo System', 'Performance Install', 'Other'];

export const STEPS = [
  { title: 'Reach Out', text: 'Tell us what car you have and what it needs.' },
  { title: 'Bring the Car', text: 'We inspect it and confirm the work.' },
  { title: 'Mechanical Work Done', text: 'We complete the service or repair.' },
];

export interface Project { id: string; image: string; title: string; text: string; alt: string; tag: string }

// Verbatim from work.html (ids kept so old deep links like work#c8-corvette still resolve).
export const PROJECTS: Project[] = [
  { id: 'blue-miata-turbo', image: 'workshop-miata', title: 'Turbo Mazda Miata', text: 'Regular maintenance on the turbo and engine system of this Mazda Miata.', alt: 'Blue turbo Mazda Miata with the hood open in the workshop', tag: 'Maintenance' },
  { id: 'miata-engine-bay', image: 'miata-engine-bay', title: '1995 Mazda Miata Turbo Build', text: 'Completing a turbo build to increase the performance output of this 1995 Mazda Miata.', alt: 'Engine bay of a 1995 Mazda Miata turbo build', tag: 'Turbo build' },
  { id: 'garage-miata', image: 'miata-garage', title: 'Mazda Miata Service', text: 'Mazda Miata getting its service done.', alt: 'Blue Mazda Miata parked in the workshop', tag: 'Service' },
  { id: 'red-na-miata', image: 'red-miata', title: 'Red Mazda Miata', text: 'Customer’s red Mazda Miata receiving routine service.', alt: 'Red first-generation Mazda Miata with pop-up headlights raised', tag: 'Service' },
  { id: 'audi-b8-coupe', image: 'audi-a5', title: 'Audi A5 Coupe', text: 'A strong street-enthusiast platform and a great starting point for performance builds. This car received turbo and engine-performance upgrades.', alt: 'White Audi A5 coupe at night', tag: 'Performance' },
  { id: 'w211-e-class', image: 'mercedes', title: 'Mercedes-Benz', text: 'An older Mercedes receiving regular service and mechanical maintenance.', alt: 'Dark blue Mercedes-Benz E-Class sedan', tag: 'Maintenance' },
  { id: 'c8-corvette', image: 'c8-corvette', title: 'Chevrolet C8 Corvette', text: 'Mid-engine Chevrolet C8 Corvette receiving an engine-oil change.', alt: 'Red Chevrolet C8 Corvette', tag: 'Oil change' },
  { id: 'porsche-987-cayman-s', image: 'porsche-cayman', title: 'Porsche Cayman S', text: 'Porsche Cayman S receiving an engine-oil change and performance upgrades.', alt: 'Red Porsche Cayman S by the coast', tag: 'Performance' },
  { id: 'classic-corvette', image: 'classic-corvette', title: 'Classic Corvette', text: 'Classic Corvette receiving engine, brake, and cooling-system maintenance.', alt: 'Red and white classic Chevrolet Corvette convertible', tag: 'Restoration care' },
];

export const WORKSHOP = {
  p1: 'Our workshop is located in Springfield, Virginia. We mainly specialize in servicing enthusiast cars, including 1990s Miatas, classic Corvettes, modified cars, and custom or DIY builds.',
  p2: 'We also service and maintain regular cars. If your car needs maintenance or repair, we are more than happy to help.',
  specialties: ['1990s Miatas', 'Classic Corvettes', 'Modified Cars', 'Custom + DIY Builds', 'Regular Cars'],
};

export const NAV = [
  { to: '/', label: 'Home' },
  { to: '/services', label: 'Services' },
  { to: '/workshop', label: 'Workshop' },
  { to: '/work', label: 'Work' },
  { to: '/contact', label: 'Contact' },
];
