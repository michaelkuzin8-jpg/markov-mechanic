import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource-variable/archivo/wdth.css';
import '@fontsource-variable/inter';
import '@fontsource/jetbrains-mono/400.css';
import '@fontsource/jetbrains-mono/500.css';
import './styles/global.css';
import gsap from 'gsap';
import App from './App';

// Test hook: headless software-GL renders ~1 fps, where GSAP's lag smoothing would slow tweens to a crawl.
if (/[?&]testclock\b/.test(location.search)) gsap.ticker.lagSmoothing(0);

if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
