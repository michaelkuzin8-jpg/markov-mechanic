import { motion, type Variants } from 'motion/react';

/** Splits text into masked characters (words kept together) for line/char reveals. */
export function Chars({ text, className = '', charClass = 'ch' }: { text: string; className?: string; charClass?: string }) {
  return (
    <span className={`split ${className}`} aria-label={text}>
      {text.split(' ').map((word, wi, arr) => (
        <span className="word" aria-hidden key={wi}>
          {[...word].map((c, ci) => <span className={charClass} key={ci}>{c}</span>)}
          {wi < arr.length - 1 ? <span className={charClass}>&nbsp;</span> : null}
        </span>
      ))}
    </span>
  );
}

const charV: Variants = {
  hidden: { y: '115%', rotate: 6, opacity: 0 },
  show: (i: number) => ({ y: '0%', rotate: 0, opacity: 1, transition: { duration: 0.9, ease: [0.16, 1, 0.3, 1], delay: i * 0.022 } }),
  exit: (i: number) => ({ y: '-110%', opacity: 0, transition: { duration: 0.45, ease: [0.7, 0, 0.84, 0], delay: i * 0.008 } }),
};

/** Motion-driven masked character reveal. `delay` offsets the whole line. */
export function RevealChars({ text, className = '', delay = 0, as = 'span' }: { text: string; className?: string; delay?: number; as?: 'span' | 'h1' | 'h2' | 'h3' }) {
  const Tag = motion[as];
  let idx = Math.round(delay / 0.022);
  return (
    <Tag className={`split ${className}`} aria-label={text} initial="hidden" animate="show" exit="exit">
      {text.split(' ').map((word, wi, arr) => (
        <span className="word mask" aria-hidden key={wi}>
          {[...word].map((c, ci) => <motion.span className="ch" key={ci} custom={idx++} variants={charV}>{c}</motion.span>)}
          {wi < arr.length - 1 ? <span className="ch">&nbsp;</span> : null}
        </span>
      ))}
    </Tag>
  );
}

/** Masked line that slides up into view. */
export function RevealLine({ children, delay = 0, className = '' }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <span className={`mask block ${className}`}>
      <motion.span
        className="block"
        initial={{ y: '105%' }}
        animate={{ y: '0%', transition: { duration: 1, ease: [0.16, 1, 0.3, 1], delay } }}
        exit={{ y: '-105%', transition: { duration: 0.4, ease: [0.7, 0, 0.84, 0] } }}
      >
        {children}
      </motion.span>
    </span>
  );
}
