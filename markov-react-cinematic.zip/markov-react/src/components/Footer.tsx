import { Link } from 'react-router';
import { BUSINESS, NAV, SERVICES } from '../data/site';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="marquee footer-marquee" aria-hidden>
        <div className="marquee-track">
          {Array.from({ length: 4 }).map((_, i) => (
            <span key={i}>Real Work Done Here <i>✕</i> Enthusiast Cars Only <i>✕</i> </span>
          ))}
        </div>
      </div>
      <div className="wrap footer-grid">
        <div className="footer-cta">
          <p className="mono eyebrow">Need service?</p>
          <h2 className="display-3">Tell us what your car needs.</h2>
          <Link to="/contact" className="btn btn-red">Schedule Service <span aria-hidden>→</span></Link>
        </div>
        <div>
          <h3 className="mono">Pages</h3>
          <ul>{NAV.map((n) => <li key={n.to}><Link to={n.to}>{n.label}</Link></li>)}</ul>
        </div>
        <div>
          <h3 className="mono">Services</h3>
          <ul>{SERVICES.map((s) => <li key={s.key}><Link to={`/services?focus=${s.key}`}>{s.title}</Link></li>)}</ul>
        </div>
        <div>
          <h3 className="mono">Shop</h3>
          <ul><li>{BUSINESS.name}</li><li>{BUSINESS.location}</li><li><Link to="/contact">Send us a message</Link></li></ul>
        </div>
      </div>
      <div className="wrap footer-bottom mono">
        <span>{BUSINESS.name} · {BUSINESS.location}</span>
        <span>{BUSINESS.footer}</span>
      </div>
    </footer>
  );
}
