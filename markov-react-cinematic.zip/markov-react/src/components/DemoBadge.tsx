export default function DemoBadge({ className = '' }: { className?: string }) {
  return (
    <div className={`demo-badge mono ${className}`} role="note">
      <span className="dot" aria-hidden />
      Procedural 3D demo · illustrative only, not a model of a specific car
    </div>
  );
}
