import { Suspense, lazy, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router';
import { AnimatePresence, motion } from 'motion/react';
import { SERVICES, type ServiceKey } from '../data/site';
import type { ExplorerApi } from '../three/ExplorerCanvas';
import { useIsTouch, useLowPower, useNearViewport, useReducedMotion } from '../lib/hooks';
import DemoBadge from './DemoBadge';
import { RevealChars } from './Split';

const ExplorerCanvas = lazy(() => import('../three/ExplorerCanvas'));

const hasWebGL = () => {
  try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch { return false; }
};

export default function Explorer({ focus, setFocus }: { focus: ServiceKey | null; setFocus: (k: ServiceKey | null) => void }) {
  const box = useRef<HTMLDivElement>(null);
  const near = useNearViewport(box, '300px');
  const visible = useNearViewport(box, '0px', false);
  const low = useLowPower();
  const reduced = useReducedMotion();
  const touch = useIsTouch();
  const api = useRef<ExplorerApi | null>(null);
  const [xray, setXray] = useState(false);
  const [spin, setSpin] = useState(true);
  const [engaged, setEngaged] = useState(false);
  const webgl = useMemo(hasWebGL, []);
  const svc = focus ? SERVICES.find((s) => s.key === focus)! : null;
  const idx = svc ? SERVICES.indexOf(svc) : -1;

  return (
    <section className="explorer" id="explorer" aria-label="Interactive 3D service explorer">
      <div className="wrap explorer-head">
        <div>
          <p className="eyebrow mono">Service Explorer</p>
          <h2 className="display-2">Inspect the build.</h2>
        </div>
        <p className="explorer-help mono">
          {touch ? 'Drag to rotate · pinch to zoom · tap a numbered hotspot' : 'Drag to rotate · click the scene then scroll to zoom · click a numbered hotspot'}
        </p>
      </div>

      <div
        className={`explorer-stage ${engaged ? 'engaged' : ''}`}
        ref={box}
        onPointerDown={() => setEngaged(true)}
        onPointerLeave={() => setEngaged(false)}
      >
        {webgl ? (
          near && (
            <Suspense fallback={<div className="canvas-loading mono">Loading 3D explorer…</div>}>
              <ExplorerCanvas
                focus={focus} onFocus={(k) => setFocus(k)} xray={xray} autoRotate={spin}
                zoomEnabled={touch || engaged} low={low} reduced={reduced} active={visible} apiRef={api}
              />
            </Suspense>
          )
        ) : (
          <div className="canvas-loading mono">3D needs WebGL, which this browser has turned off. All service details are listed below.</div>
        )}

        <DemoBadge className="explorer-badge" />

        <div className="explorer-controls" role="toolbar" aria-label="3D view controls">
          <button type="button" onClick={() => api.current?.zoom(1)} aria-label="Zoom in">+</button>
          <button type="button" onClick={() => api.current?.zoom(-1)} aria-label="Zoom out">−</button>
          <button type="button" onClick={() => { setFocus(null); api.current?.reset(); }} className="mono">Reset</button>
          <button type="button" onClick={() => setXray((x) => !x)} aria-pressed={xray} className="mono">X-ray</button>
          <button type="button" onClick={() => setSpin((x) => !x)} aria-pressed={spin} className="mono">Auto-rotate</button>
        </div>

        <AnimatePresence mode="wait">
          {svc && (
            <motion.aside
              key={svc.key}
              className="explorer-panel"
              initial={{ opacity: 0, x: 40, clipPath: 'inset(0 0 0 100%)' }}
              animate={{ opacity: 1, x: 0, clipPath: 'inset(0 0 0 0%)', transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } }}
              exit={{ opacity: 0, x: 30, transition: { duration: 0.3 } }}
              aria-live="polite"
            >
              <button type="button" className="panel-close" onClick={() => setFocus(null)} aria-label="Close detail">✕</button>
              <p className="mono red">{String(idx + 1).padStart(2, '0')} / 05</p>
              <RevealChars as="h3" text={svc.title} className="panel-title" />
              <p className="panel-kicker">{svc.short}</p>
              <p>{svc.text}</p>
              <p className="chapter-parts mono"><span className="dot" />Highlighted: {svc.parts}</p>
              <div className="actions">
                <Link className="btn btn-red btn-sm" to={`/contact?service=${encodeURIComponent(svc.formValue)}`}>Request this service <span aria-hidden>→</span></Link>
              </div>
              <div className="panel-nav">
                <button type="button" className="mono" onClick={() => setFocus(SERVICES[(idx + 4) % 5].key)}>← Prev</button>
                <button type="button" className="mono" onClick={() => setFocus(SERVICES[(idx + 1) % 5].key)}>Next →</button>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>

      <div className="wrap explorer-tabs" role="tablist" aria-label="Services">
        {SERVICES.map((s, i) => (
          <button key={s.key} type="button" role="tab" aria-selected={focus === s.key} className={focus === s.key ? 'on' : ''} onClick={() => setFocus(focus === s.key ? null : s.key)}>
            <span className="mono">{String(i + 1).padStart(2, '0')}</span>
            <span>{s.title}</span>
            {focus === s.key && <motion.i layoutId="tab-ind" className="tab-ind" transition={{ type: 'spring', stiffness: 400, damping: 34 }} />}
          </button>
        ))}
      </div>
    </section>
  );
}
