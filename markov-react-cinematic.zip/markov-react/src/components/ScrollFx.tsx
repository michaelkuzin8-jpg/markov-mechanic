import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { STEPS } from '../data/site';
import { imgSet, imgSrc, imgSize, prefersReducedMotion } from '../lib/hooks';

gsap.registerPlugin(ScrollTrigger);

/** Paragraph whose words light up one by one as it scrolls past. */
export function ScrubText({ text, className = '' }: { text: string; className?: string }) {
  const root = useRef<HTMLParagraphElement>(null);
  useGSAP(() => {
    if (prefersReducedMotion()) return;
    gsap.fromTo('.w', { opacity: 0.14 }, {
      opacity: 1, stagger: 0.05, ease: 'none',
      scrollTrigger: { trigger: root.current, start: 'top 85%', end: 'bottom 45%', scrub: true },
    });
  }, { scope: root });
  return (
    <p className={`scrub-text ${className}`} ref={root} aria-label={text}>
      {text.split(' ').map((w, i) => <span className="w" aria-hidden key={i}>{w} </span>)}
    </p>
  );
}

/** Oversized rows of type that slide in opposite directions with scroll. */
export function KineticRows({ items }: { items: string[] }) {
  const root = useRef<HTMLDivElement>(null);
  useGSAP(() => {
    if (prefersReducedMotion()) return;
    gsap.utils.toArray<HTMLElement>('.k-row').forEach((row, i) => {
      gsap.fromTo(row, { xPercent: i % 2 ? -18 : 4 }, {
        xPercent: i % 2 ? 4 : -18, ease: 'none',
        scrollTrigger: { trigger: root.current, start: 'top bottom', end: 'bottom top', scrub: true },
      });
    });
  }, { scope: root });
  const rows = [items.slice(0, 3), items.slice(2), items.slice(0, 2).concat(items.slice(3))];
  return (
    <div className="kinetic" ref={root} aria-label={items.join(', ')}>
      {rows.map((r, i) => (
        <div className={`k-row ${i === 1 ? 'outline' : ''}`} aria-hidden key={i}>
          {[...r, ...r].map((t, j) => <span key={j}>{t}<i>●</i></span>)}
        </div>
      ))}
    </div>
  );
}

/** Pinned horizontal gallery: vertical scroll drives a sideways track of large photos. */
export function HorizontalGallery({ items }: { items: { image: string; title: string; text: string; alt: string }[] }) {
  const root = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);
  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add('(min-width: 821px) and (prefers-reduced-motion: no-preference)', () => {
      const dist = () => (track.current ? track.current.scrollWidth - window.innerWidth : 0);
      gsap.to(track.current, {
        x: () => -dist(), ease: 'none',
        scrollTrigger: { trigger: root.current, start: 'top top', end: () => `+=${dist()}`, scrub: 0.6, pin: true, invalidateOnRefresh: true, anticipatePin: 1 },
      });
      gsap.utils.toArray<HTMLElement>('.hg-card img').forEach((img) => {
        gsap.fromTo(img, { scale: 1.25 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: root.current, start: 'top top', end: () => `+=${dist()}`, scrub: true } });
      });
    });
    return () => mm.revert();
  }, { scope: root });

  return (
    <section className="hgallery" ref={root} aria-label="Workshop gallery">
      <div className="hg-track" ref={track}>
        <div className="hg-intro">
          <p className="eyebrow mono">Inside the shop</p>
          <h2 className="display-2">On the floor right now.</h2>
          <p className="mono muted">Scroll →</p>
        </div>
        {items.map((it, i) => {
          const [w, h] = imgSize(it.image);
          return (
            <figure className="hg-card" key={it.image}>
              <div className="hg-img"><img src={imgSrc(it.image)} srcSet={imgSet(it.image)} sizes="(max-width: 820px) 90vw, 55vw" width={w} height={h} alt={it.alt} loading="lazy" decoding="async" /></div>
              <figcaption><span className="mono red">{String(i + 1).padStart(2, '0')}</span><strong>{it.title}</strong><span>{it.text}</span></figcaption>
            </figure>
          );
        })}
      </div>
    </section>
  );
}

/** The three steps, with a progress line drawn by scroll and numbers that scale in. */
export function Steps() {
  const root = useRef<HTMLElement>(null);
  useGSAP(() => {
    if (prefersReducedMotion()) return;
    gsap.fromTo('.steps-fill', { scaleX: 0 }, { scaleX: 1, ease: 'none', scrollTrigger: { trigger: root.current, start: 'top 70%', end: 'bottom 70%', scrub: true } });
    gsap.utils.toArray<HTMLElement>('.step-x').forEach((el) => {
      gsap.fromTo(el.querySelector('.step-n'), { yPercent: 100 }, { yPercent: 0, ease: 'power3.out', duration: 1, scrollTrigger: { trigger: el, start: 'top 85%' } });
      gsap.fromTo(el.querySelectorAll('h3, p'), { y: 30, opacity: 0 }, { y: 0, opacity: 1, stagger: 0.1, duration: 1, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 85%' } });
    });
  }, { scope: root });
  return (
    <section className="steps-x wrap" ref={root} aria-label="How it works">
      <div className="steps-head">
        <p className="eyebrow mono">How it works</p>
        <h2 className="display-2">Three Simple Steps.</h2>
      </div>
      <div className="steps-line" aria-hidden><i className="steps-fill" /></div>
      <ol className="steps-list">
        {STEPS.map((s, i) => (
          <li className="step-x" key={s.title}>
            <span className="step-mask"><span className="step-n">{i + 1}</span></span>
            <h3>{s.title}</h3>
            <p>{s.text}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
