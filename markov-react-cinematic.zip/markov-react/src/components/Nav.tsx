import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router';
import { AnimatePresence, motion } from 'motion/react';
import { BUSINESS, NAV } from '../data/site';
import Magnetic from './Magnetic';

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle('menu-lock', open);
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <header className={`nav ${scrolled ? 'scrolled' : ''} ${open ? 'open' : ''}`}>
        <Link to="/" className="logo" aria-label="Markov Auto, home">
          <span className="logo-mark" aria-hidden>M</span>
          <span className="logo-text">MARKOV<b>AUTO</b></span>
        </Link>
        <nav className="nav-links" aria-label="Main">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.to === '/'} className="nav-link">
              {({ isActive }) => (
                <>
                  <span>{n.label}</span>
                  {isActive && <motion.i layoutId="nav-ind" className="nav-ind" transition={{ type: 'spring', stiffness: 380, damping: 32 }} />}
                </>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="nav-right">
          <span className="nav-loc mono">{BUSINESS.location}</span>
          <Magnetic><Link to="/contact" className="btn btn-red btn-sm">Schedule Service</Link></Magnetic>
          <button className="burger" type="button" aria-expanded={open} aria-controls="menu" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen((o) => !o)}>
            <span /><span />
          </button>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="menu" className="menu" role="dialog" aria-modal="true" aria-label="Menu"
            initial={{ clipPath: 'inset(0 0 100% 0)' }}
            animate={{ clipPath: 'inset(0 0 0% 0)', transition: { duration: 0.7, ease: [0.76, 0, 0.24, 1] } }}
            exit={{ clipPath: 'inset(0 0 100% 0)', transition: { duration: 0.5, ease: [0.76, 0, 0.24, 1] } }}
          >
            <nav className="menu-links" aria-label="Mobile">
              {NAV.map((n, i) => (
                <span className="mask" key={n.to}>
                  <motion.span
                    className="block"
                    initial={{ y: '110%' }}
                    animate={{ y: '0%', transition: { delay: 0.25 + i * 0.06, duration: 0.8, ease: [0.16, 1, 0.3, 1] } }}
                    exit={{ y: '110%', transition: { duration: 0.3 } }}
                  >
                    <NavLink to={n.to} end={n.to === '/'} className="menu-link">
                      <span className="mono">0{i + 1}</span>{n.label}
                    </NavLink>
                  </motion.span>
                </span>
              ))}
            </nav>
            <motion.div className="menu-foot" initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 0.6 } }}>
              <Link to="/contact" className="btn btn-red">Schedule Service <span aria-hidden>→</span></Link>
              <p className="mono">{BUSINESS.name} · {BUSINESS.location}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
