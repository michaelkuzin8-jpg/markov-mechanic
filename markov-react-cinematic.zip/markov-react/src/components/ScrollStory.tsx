import { Suspense, lazy, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router';
import { AnimatePresence, motion } from 'motion/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { BUSINESS, SERVICES } from '../data/site';
import { KEYFRAMES } from '../three/storyPath';
import type { StoryStore } from '../three/StoryCanvas';
import { imgSet, imgSrc, useLowPower, useNearViewport, useReducedMotion } from '../lib/hooks';
import { useIntroDone } from '../lib/intro';
import { RevealChars, RevealLine } from './Split';
import DemoBadge from './DemoBadge';

gsap.registerPlugin(ScrollTrigger);
const StoryCanvas = lazy(() => import('../three/StoryCanvas'));

const CHAPTERS = KEYFRAMES.length; // 0 hero, 1-5 services, 6 outro
const LABELS = ['Intro', ...SERVICES.map((s) => s.title), 'Book'];

const hasWebGL = () => {
  try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch { return false; }
};

export default function ScrollStory() {
  const section = useRef<HTMLElement>(null);
  const bar = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const activeRef = useRef(0);
  const story = useMemo<StoryStore>(() => ({ progress: 0, px: 0, py: 0 }), []);
  const low = useLowPower();
  const reduced = useReducedMotion();
  const introDone = useIntroDone();
  const inView = useNearViewport(section, '0px', false);
  const webgl = useMemo(hasWebGL, []);

  useGSAP(() => {
    ScrollTrigger.create({
      trigger: section.current,
      start: 'top top',
      end: 'bottom bottom',
      onUpdate: (self) => {
        story.progress = self.progress;
        if (bar.current) bar.current.style.transform = `scaleX(${self.progress})`;
        const idx = Math.round(self.progress * (CHAPTERS - 1));
        if (idx !== activeRef.current) { activeRef.current = idx; setActive(idx); }
      },
    });
  }, { scope: section });

  const goTo = (i: number) => {
    const el = section.current;
    if (!el) return;
    const top = el.getBoundingClientRect().top + window.scrollY;
    const span = el.offsetHeight - window.innerHeight;
    window.scrollTo({ top: top + (span * i) / (CHAPTERS - 1) + 2, behavior: reduced ? 'auto' : 'smooth' });
  };

  const onPointer = (e: React.PointerEvent) => {
    if (e.pointerType !== 'mouse') return;
    story.px = (e.clientX / window.innerWidth) * 2 - 1;
    story.py = (e.clientY / window.innerHeight) * 2 - 1;
  };

  const svc = active >= 1 && active <= 5 ? SERVICES[active - 1] : null;

  return (
    <section className="story" ref={section} style={{ height: `${CHAPTERS * 100 + 40}vh` }} onPointerMove={onPointer} aria-label="Markov Auto services, told through a 3D demo car">
      <div className="story-sticky">
        <div className="story-canvas">
          {webgl ? (
            <Suspense fallback={<div className="canvas-loading mono">Loading 3D scene…</div>}>
              <StoryCanvas story={story} low={low} reduced={reduced} active={inView} />
            </Suspense>
          ) : (
            <img className="story-fallback" src={imgSrc('hero-garage')} srcSet={imgSet('hero-garage')} sizes="100vw" alt="" />
          )}
        </div>
        <div className="story-vignette" aria-hidden />
        {webgl && <DemoBadge />}

        <div className="story-ui wrap">
          <AnimatePresence mode="wait">
            {active === 0 && introDone && (
              <motion.div key="hero" className="story-hero" exit={{ opacity: 0, transition: { duration: 0.35 } }}>
                <RevealLine className="eyebrow mono" delay={0.1}>{BUSINESS.name} · {BUSINESS.location}</RevealLine>
                <h1 className="display">
                  <RevealChars text="Enthusiast" delay={0.15} />
                  <RevealChars text="Cars Only." delay={0.3} />
                  <RevealChars text="Real Work" delay={0.5} className="line-b" />
                  <RevealChars text="Done Here." delay={0.65} className="line-b" />
                </h1>
                <motion.div className="story-hero-foot" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.9, duration: 0.9, ease: [0.16, 1, 0.3, 1] } }}>
                  <p className="lead">{BUSINESS.summary}</p>
                  <div className="actions">
                    <Link className="btn btn-red" to="/contact">Schedule Service <span aria-hidden>→</span></Link>
                    <Link className="btn btn-ghost" to="/work">See Work</Link>
                  </div>
                  <div className="chips"><Link to="/services">Mechanical Service</Link><Link to="/workshop">Modified Cars</Link></div>
                </motion.div>
              </motion.div>
            )}

            {svc && (
              <motion.article key={svc.key} className="story-chapter" exit={{ opacity: 0, transition: { duration: 0.35 } }}>
                <div className="chapter-index mono">
                  <RevealLine>{String(active).padStart(2, '0')} / 05 — Service</RevealLine>
                </div>
                <RevealChars as="h2" text={svc.title} className="chapter-title" />
                <RevealLine className="chapter-kicker" delay={0.25}>{svc.short}</RevealLine>
                <motion.div className="chapter-body" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0, transition: { delay: 0.4, duration: 0.8, ease: [0.16, 1, 0.3, 1] } }}>
                  <p>{svc.text}</p>
                  <p className="chapter-parts mono"><span className="dot" />Highlighted in demo: {svc.parts}</p>
                  <div className="actions">
                    <Link className="btn btn-red" to={`/contact?service=${encodeURIComponent(svc.formValue)}`}>Request this service <span aria-hidden>→</span></Link>
                    <Link className="btn btn-ghost" to={`/services?focus=${svc.key}`}>Inspect in 3D</Link>
                  </div>
                </motion.div>
              </motion.article>
            )}

            {active === CHAPTERS - 1 && (
              <motion.div key="outro" className="story-outro" exit={{ opacity: 0, transition: { duration: 0.35 } }}>
                <RevealLine className="eyebrow mono">Need Service Immediately?</RevealLine>
                <RevealChars as="h2" text="Bring the car." className="display-2" />
                <RevealChars as="h2" text="We do the real work." className="display-2 red" delay={0.25} />
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.6, duration: 0.8 } }}>
                  <p className="lead">Contact us and tell us what is happening with your car.</p>
                  <div className="actions"><Link className="btn btn-red" to="/contact">Schedule Service <span aria-hidden>→</span></Link><Link className="btn btn-ghost" to="/services">All Services</Link></div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <nav className="story-rail" aria-label="Story chapters">
          {LABELS.map((l, i) => (
            <button key={l} type="button" className={i === active ? 'on' : ''} onClick={() => goTo(i)} aria-current={i === active ? 'step' : undefined}>
              <span className="mono">{String(i).padStart(2, '0')}</span><span className="rail-label">{l}</span>
            </button>
          ))}
        </nav>

        <div className="story-progress" aria-hidden><div ref={bar} /></div>
        <AnimatePresence>
          {active === 0 && introDone && (
            <motion.div className="scroll-cue mono" initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 1.4 } }} exit={{ opacity: 0 }}>
              <span>Scroll to drive the story</span><i />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
