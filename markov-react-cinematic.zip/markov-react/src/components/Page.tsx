import { useEffect } from 'react';
import { motion } from 'motion/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Footer from './Footer';
import { useReducedMotion } from '../lib/hooks';

const COLS = 6;
const EASE = [0.76, 0, 0.24, 1] as const;

/**
 * Wraps each route. On exit a two-layer (red, then charcoal) column wipe covers the
 * screen; the next page mounts underneath the cover and the wipe retracts, so there
 * is never a blank flash. Reduced motion gets a plain cross-fade.
 */
export default function Page({ title, children, footer = true }: { title: string; children: React.ReactNode; footer?: boolean }) {
  const reduced = useReducedMotion();

  useEffect(() => {
    document.title = title === 'Home' ? 'Markov Auto | Enthusiast Mechanical Shop · Springfield, Virginia' : `${title} | Markov Auto`;
    const id = window.setTimeout(() => ScrollTrigger.refresh(), 900);
    return () => window.clearTimeout(id);
  }, [title]);

  if (reduced) {
    return (
      <motion.main id="main" initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: 0.3 } }} exit={{ opacity: 0, transition: { duration: 0.2 } }}>
        {children}
        {footer && <Footer />}
      </motion.main>
    );
  }

  const cols = Array.from({ length: COLS }, (_, i) => i);
  return (
    <>
      <motion.main id="main" className="page" exit={{ opacity: 1, transition: { duration: 0.95 } }}>
        {children}
        {footer && <Footer />}
      </motion.main>
      <div className="wipe" aria-hidden>
        {cols.map((i) => (
          <motion.div
            key={`r${i}`} className="wipe-col red"
            initial={{ scaleY: 1, originY: 0 }}
            animate={{ scaleY: 0, originY: 0, transition: { duration: 0.75, delay: 0.22 + i * 0.045, ease: EASE } }}
            exit={{ scaleY: 1, originY: 1, transition: { duration: 0.55, delay: i * 0.045, ease: EASE } }}
          />
        ))}
        {cols.map((i) => (
          <motion.div
            key={`b${i}`} className="wipe-col"
            initial={{ scaleY: 1, originY: 0 }}
            animate={{ scaleY: 0, originY: 0, transition: { duration: 0.7, delay: 0.12 + i * 0.045, ease: EASE } }}
            exit={{ scaleY: 1, originY: 1, transition: { duration: 0.55, delay: 0.1 + i * 0.045, ease: EASE } }}
          />
        ))}
        <motion.div
          className="wipe-title"
          initial={{ opacity: 1, y: 0 }}
          animate={{ opacity: 0, y: -30, transition: { duration: 0.4, delay: 0.1, ease: EASE } }}
          exit={{ opacity: 0 }}
        >
          <span className="mono">Markov Auto</span>
          {title}
        </motion.div>
      </div>
    </>
  );
}
