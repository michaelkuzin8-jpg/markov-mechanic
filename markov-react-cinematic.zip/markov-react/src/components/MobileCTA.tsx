import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router';
import { AnimatePresence, motion } from 'motion/react';

/** Thumb-reachable booking bar on phones (hidden on the contact page). */
export default function MobileCTA() {
  const { pathname } = useLocation();
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 500);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [pathname]);
  return (
    <AnimatePresence>
      {show && pathname !== '/contact' && (
        <motion.div className="mobile-cta" initial={{ y: 120 }} animate={{ y: 0 }} exit={{ y: 120 }} transition={{ type: 'spring', stiffness: 260, damping: 28 }}>
          <Link className="btn btn-red" to="/contact">Schedule Service</Link>
          <Link className="btn btn-ghost" to="/services">Services</Link>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
