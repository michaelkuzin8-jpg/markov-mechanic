import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { motion } from 'motion/react';
import { RevealChars } from './Split';
import { imgSet, imgSrc, imgSize, prefersReducedMotion } from '../lib/hooks';

gsap.registerPlugin(ScrollTrigger);

/** Layered page header: photo, oversized outline index, masked headline; each layer scrolls at its own speed. */
export default function PageHero({ eyebrow, lines, image, index, children }: {
  eyebrow: string; lines: string[]; image: string; index: string; children?: React.ReactNode;
}) {
  const root = useRef<HTMLElement>(null);
  const [w, h] = imgSize(image);

  useGSAP(() => {
    if (prefersReducedMotion()) return;
    const st = { trigger: root.current, start: 'top top', end: 'bottom top', scrub: true };
    gsap.to('.ph-media', { yPercent: 18, scale: 1.08, ease: 'none', scrollTrigger: st });
    gsap.to('.ph-index', { yPercent: -40, ease: 'none', scrollTrigger: st });
    gsap.to('.ph-copy', { yPercent: -30, opacity: 0.2, ease: 'none', scrollTrigger: st });
  }, { scope: root });

  return (
    <header className="pagehero-x" ref={root}>
      <motion.div
        className="ph-media"
        initial={{ clipPath: 'inset(18% 12% 18% 40%)' }}
        animate={{ clipPath: 'inset(0% 0% 0% 0%)', transition: { duration: 1.6, ease: [0.76, 0, 0.24, 1], delay: 0.35 } }}
      >
        <img src={imgSrc(image)} srcSet={imgSet(image)} sizes="100vw" width={w} height={h} alt="" fetchPriority="high" />
      </motion.div>
      <div className="ph-shade" aria-hidden />
      <span className="ph-index" aria-hidden>{index}</span>
      <div className="wrap ph-copy">
        <motion.p className="eyebrow mono" initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 0.5 } }}>{eyebrow}</motion.p>
        <h1 className="display">
          {lines.map((l, i) => <RevealChars key={l} text={l} delay={0.45 + i * 0.18} className="ph-line" />)}
        </h1>
        {children && (
          <motion.p className="lead" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0, transition: { delay: 1.1, duration: 0.9 } }}>{children}</motion.p>
        )}
      </div>
    </header>
  );
}
