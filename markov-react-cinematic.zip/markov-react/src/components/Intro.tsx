import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { Chars } from './Split';
import { finishIntro, intro, useIntroDone } from '../lib/intro';

/**
 * Cinematic intro. Full sequence on first visit (~4.5s), compressed for returning
 * visitors, skipped entirely with prefers-reduced-motion. While it plays, it drives
 * the 3D scene's light level (headlights flicker on) and camera dolly via `intro`.
 */
export default function Intro() {
  const done = useIntroDone();
  const root = useRef<HTMLDivElement>(null);
  const tl = useRef<gsap.core.Timeline | null>(null);

  useGSAP(() => {
    if (intro.done) return;
    const html = document.documentElement;
    html.classList.add('intro-lock');
    const q = gsap.utils.selector(root);
    const light = { v: 0 };
    const cam = { v: 0 };

    const t = gsap.timeline({
      defaults: { ease: 'expo.out' },
      onComplete: () => { html.classList.remove('intro-lock'); finishIntro(); },
    });
    tl.current = t;

    t.set(q('.intro-title .ch'), { yPercent: 125, filter: 'blur(14px)', opacity: 0 })
      .set(q('.intro-title'), { letterSpacing: '0.42em' })
      .fromTo(q('.intro-line'), { scaleX: 0 }, { scaleX: 1, duration: 1.1, ease: 'expo.inOut' }, 0)
      .to(q('.intro-title .ch'), { yPercent: 0, filter: 'blur(0px)', opacity: 1, duration: 1.3, stagger: 0.07 }, 0.25)
      .to(q('.intro-title'), { letterSpacing: '0.06em', duration: 2.6, ease: 'power3.out' }, 0.25)
      .fromTo(q('.intro-auto'), { opacity: 0, letterSpacing: '1.4em' }, { opacity: 1, letterSpacing: '0.7em', duration: 1.6, ease: 'power3.out' }, 0.7)
      .fromTo(q('.intro-meta > span'), { yPercent: 100, opacity: 0 }, { yPercent: 0, opacity: 1, duration: 0.9, stagger: 0.12 }, 0.9)
      .fromTo(q('.intro-sweep'), { xPercent: -120 }, { xPercent: 120, duration: 1.5, ease: 'power2.inOut' }, 1.0)
      // Lighting reveal: bloom opens, scene lights flicker on behind the title
      .fromTo(q('.intro-glow'), { scale: 0.2, opacity: 0 }, { scale: 1, opacity: 1, duration: 2.2, ease: 'power2.out' }, 1.1)
      .to(light, {
        v: 1, duration: 1.9, ease: 'power1.in',
        onUpdate: () => { intro.light = light.v * (light.v < 0.7 && Math.random() < 0.3 ? 0.15 : 1); },
      }, 1.2)
      .to(cam, { v: 1, duration: 3.2, ease: 'power2.inOut', onUpdate: () => { intro.cam = cam.v; } }, 1.3)
      .to(q('.intro-panel'), { backgroundColor: 'rgba(5,5,5,0.38)', duration: 1.6, ease: 'power2.inOut' }, 1.5)
      .to(q('.intro-center'), { scale: 1.08, duration: 2.2, ease: 'power1.inOut' }, 1.3)
      .to(q('.intro-counter'), { innerText: 100, snap: { innerText: 1 }, duration: 2.6, ease: 'power1.inOut' }, 0.2)
      // Exit
      .to(q('.intro-title .ch'), { yPercent: -130, opacity: 0, duration: 0.7, stagger: 0.035, ease: 'power3.in' }, 3.15)
      .to(q('.intro-auto, .intro-meta, .intro-line, .intro-hud, .intro-glow'), { opacity: 0, duration: 0.5, ease: 'power2.in' }, 3.25)
      .to(q('.intro-panel.top'), { yPercent: -100, duration: 1.05, ease: 'expo.inOut' }, 3.55)
      .to(q('.intro-panel.bot'), { yPercent: 100, duration: 1.05, ease: 'expo.inOut' }, 3.55)
      .to(q('.intro-skip'), { opacity: 0, duration: 0.3 }, 3.55);

    if (intro.mode === 'short') t.timeScale(2.6);

    return () => { html.classList.remove('intro-lock'); };
  }, { scope: root });

  useEffect(() => {
    if (done) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') tl.current?.progress(1); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [done]);

  if (done) return null;
  return (
    <div className="intro" ref={root} aria-label="Markov Auto intro" role="presentation">
      <div className="intro-panel top" />
      <div className="intro-panel bot" />
      <div className="intro-glow" aria-hidden />
      <div className="intro-center">
        <div className="intro-meta mono"><span>Enthusiast Mechanical Shop</span><span>Springfield, Virginia</span></div>
        <div className="intro-titlewrap">
          <h1 className="intro-title"><Chars text="MARKOV" /></h1>
          <div className="intro-sweep" aria-hidden />
        </div>
        <div className="intro-line" />
        <div className="intro-auto">AUTO</div>
      </div>
      <div className="intro-hud mono" aria-hidden>
        <span>Lighting</span><span className="intro-counter">0</span><span>%</span>
      </div>
      <button className="intro-skip mono" type="button" onClick={() => tl.current?.progress(1)}>
        Skip intro <span aria-hidden>→</span>
      </button>
    </div>
  );
}
