import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { imgSet, imgSrc, imgSize, prefersReducedMotion } from '../lib/hooks';

gsap.registerPlugin(ScrollTrigger);

/** Photo that opens from a narrow slit to full frame as it scrolls through the viewport. */
export default function ClipImage({ name, alt, className = '', sizes = '(max-width: 900px) 100vw, 50vw', caption }: {
  name: string; alt: string; className?: string; sizes?: string; caption?: string;
}) {
  const root = useRef<HTMLElement>(null);
  const [w, h] = imgSize(name);
  useGSAP(() => {
    if (prefersReducedMotion()) return;
    const st = { trigger: root.current, start: 'top 92%', end: 'top 30%', scrub: 0.8 };
    gsap.fromTo(root.current, { clipPath: 'inset(22% 18% 22% 18%)' }, { clipPath: 'inset(0% 0% 0% 0%)', ease: 'none', scrollTrigger: st });
    gsap.fromTo('img', { scale: 1.35 }, { scale: 1, ease: 'none', scrollTrigger: st });
    gsap.fromTo('img', { yPercent: -6 }, { yPercent: 6, ease: 'none', scrollTrigger: { trigger: root.current, start: 'top bottom', end: 'bottom top', scrub: true } });
  }, { scope: root });
  return (
    <figure className={`clip-image ${className}`} ref={root}>
      <img src={imgSrc(name)} srcSet={imgSet(name)} sizes={sizes} width={w} height={h} alt={alt} loading="lazy" decoding="async" />
      {caption && <figcaption className="mono">{caption}</figcaption>}
    </figure>
  );
}
