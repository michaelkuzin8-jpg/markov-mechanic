import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router';
import { AnimatePresence, motion, useMotionValue, useSpring } from 'motion/react';
import { SERVICES, type Service, type ServiceKey } from '../data/site';
import { imgSet, imgSrc, imgSize } from '../lib/hooks';
import { RevealChars } from './Split';

const EASE = [0.16, 1, 0.3, 1] as const;

function Row({ s, i, onOpen }: { s: Service; i: number; onOpen: (k: ServiceKey) => void }) {
  const ref = useRef<HTMLButtonElement>(null);
  const rx = useSpring(useMotionValue(0), { stiffness: 200, damping: 20 });
  const ry = useSpring(useMotionValue(0), { stiffness: 200, damping: 20 });
  const fx = useSpring(useMotionValue(0), { stiffness: 260, damping: 26 });
  const fy = useSpring(useMotionValue(0), { stiffness: 260, damping: 26 });

  const move = (e: React.PointerEvent) => {
    if (e.pointerType !== 'mouse' || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    ref.current.style.setProperty('--mx', `${px * 100}%`);
    ref.current.style.setProperty('--my', `${py * 100}%`);
    rx.set((0.5 - py) * 6);
    ry.set((px - 0.5) * 4);
    fx.set(e.clientX - r.left);
    fy.set(e.clientY - r.top);
  };
  const leave = () => { rx.set(0); ry.set(0); };

  return (
    <motion.button
      ref={ref}
      type="button"
      className="svc-row"
      onPointerMove={move}
      onPointerLeave={leave}
      onClick={() => onOpen(s.key)}
      style={{ rotateX: rx, rotateY: ry }}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-10% 0px' }}
      transition={{ duration: 0.9, ease: EASE, delay: i * 0.06 }}
      aria-haspopup="dialog"
    >
      <span className="svc-num mono">{String(i + 1).padStart(2, '0')}</span>
      <span className="svc-title">
        <span className="svc-title-a">{s.title}</span>
        <span className="svc-title-b" aria-hidden>{s.title}</span>
      </span>
      <span className="svc-short">{s.short}</span>
      <motion.span className="svc-thumb" layoutId={`svc-img-${s.key}`}>
        <img src={imgSrc(`${s.image}-800`)} alt="" loading="lazy" decoding="async" />
      </motion.span>
      <span className="svc-arrow" aria-hidden>↗</span>
      <motion.span className="svc-follow" style={{ x: fx, y: fy }} aria-hidden>
        <img src={imgSrc(`${s.image}-800`)} alt="" loading="lazy" decoding="async" />
      </motion.span>
    </motion.button>
  );
}

function Detail({ startKey, onClose, onExplore }: { startKey: ServiceKey; onClose: () => void; onExplore: (k: ServiceKey) => void }) {
  const [cur, setCur] = useState(startKey);
  const i = SERVICES.findIndex((s) => s.key === cur);
  const s = SERVICES[i];
  const close = useRef<HTMLButtonElement>(null);
  const go = (d: number) => setCur(SERVICES[(i + d + SERVICES.length) % SERVICES.length].key);

  useEffect(() => {
    document.documentElement.classList.add('menu-lock');
    close.current?.focus();
    return () => document.documentElement.classList.remove('menu-lock');
  }, []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'ArrowLeft') go(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const [w, h] = imgSize(s.image);
  return (
    <motion.div className="svc-detail" role="dialog" aria-modal="true" aria-label={s.title}
      initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: 0.4 } }} exit={{ opacity: 0, transition: { duration: 0.4, delay: 0.25 } }}>
      <motion.div className="svc-detail-media" layoutId={`svc-img-${startKey}`} transition={{ duration: 0.85, ease: EASE }}>
        <AnimatePresence initial={false}>
          <motion.img
            key={s.key}
            src={imgSrc(s.image)} srcSet={imgSet(s.image)} sizes="(max-width: 900px) 100vw, 55vw" width={w} height={h} alt={s.imageAlt}
            initial={{ clipPath: 'inset(0 0 0 100%)', scale: 1.18 }}
            animate={{ clipPath: 'inset(0 0 0 0%)', scale: 1, transition: { duration: 1.1, ease: [0.76, 0, 0.24, 1] } }}
            exit={{ opacity: 1, transition: { duration: 1.1 } }}
          />
        </AnimatePresence>
        <div className="svc-detail-shade" />
        <AnimatePresence mode="wait">
          <motion.span key={s.key} className="svc-detail-bignum" initial={{ y: '40%', opacity: 0 }} animate={{ y: 0, opacity: 1, transition: { duration: 1, ease: EASE, delay: 0.2 } }} exit={{ y: '-30%', opacity: 0 }}>
            {String(i + 1).padStart(2, '0')}
          </motion.span>
        </AnimatePresence>
      </motion.div>

      <div className="svc-detail-body">
        <AnimatePresence mode="wait">
          <motion.div key={s.key} className="svc-detail-copy" exit={{ opacity: 0, transition: { duration: 0.25 } }}>
            <p className="eyebrow mono">Service {String(i + 1).padStart(2, '0')} / 05</p>
            <RevealChars as="h2" text={s.title} className="display-2" delay={0.15} />
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.45, duration: 0.8, ease: EASE } }}>
              <p className="svc-detail-kicker">{s.short}</p>
              <p className="svc-detail-text">{s.text}</p>
              <p className="chapter-parts mono"><span className="dot" />In the 3D demo: {s.parts}</p>
              <div className="actions">
                <Link className="btn btn-red" to={`/contact?service=${encodeURIComponent(s.formValue)}`}>Request this service <span aria-hidden>→</span></Link>
                <button type="button" className="btn btn-ghost" onClick={() => onExplore(s.key)}>View in 3D</button>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>

        <nav className="svc-detail-nav" aria-label="Browse services">
          <button type="button" className="mono" onClick={() => go(-1)}>← {SERVICES[(i + 4) % 5].title}</button>
          <div className="svc-dots">{SERVICES.map((x) => <button key={x.key} type="button" className={x.key === cur ? 'on' : ''} onClick={() => setCur(x.key)} aria-label={x.title} />)}</div>
          <button type="button" className="mono" onClick={() => go(1)}>{SERVICES[(i + 1) % 5].title} →</button>
        </nav>
      </div>
      <button ref={close} type="button" className="svc-detail-close mono" onClick={onClose}>Close ✕</button>
    </motion.div>
  );
}

export default function ServiceDeck({ onExplore }: { onExplore: (k: ServiceKey) => void }) {
  const [open, setOpen] = useState<ServiceKey | null>(null);
  return (
    <section className="svc-deck wrap" aria-label="Services">
      <div className="svc-deck-head">
        <p className="eyebrow mono">Everything in-house</p>
        <p className="mono muted">Select a service to open it</p>
      </div>
      <div className="svc-rows">
        {SERVICES.map((s, i) => <Row key={s.key} s={s} i={i} onOpen={setOpen} />)}
      </div>
      <AnimatePresence>
        {open && <Detail key="detail" startKey={open} onClose={() => setOpen(null)} onExplore={(k) => { setOpen(null); onExplore(k); }} />}
      </AnimatePresence>
    </section>
  );
}
