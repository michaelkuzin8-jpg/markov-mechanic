import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { ContactShadows, Environment, Lightformer, MeshReflectorMaterial } from '@react-three/drei';
import { damp, type CarState } from './carState';

/** Dark studio: procedural environment lighting (no HDR download), key/rim lights, reflective floor. */
export default function Studio({ state, low }: { state: CarState; low: boolean }) {
  const key = useRef<THREE.SpotLight>(null);
  const rim = useRef<THREE.SpotLight>(null);
  const fill = useRef<THREE.PointLight>(null);
  const strips = useMemo(() => new THREE.MeshBasicMaterial({ color: '#ffffff', toneMapped: false, side: THREE.DoubleSide }), []);
  useEffect(() => () => strips.dispose(), [strips]);
  const ring = useRef<THREE.MeshBasicMaterial>(null);
  const lvl = useRef(state.light);

  useFrame(({ scene }, delta) => {
    const l = (lvl.current = damp(lvl.current, state.light, 3, Math.min(delta, 0.05)));
    scene.environmentIntensity = 0.06 + 0.94 * l;
    if (key.current) key.current.intensity = 70 * l * l;
    if (rim.current) rim.current.intensity = 55 * l;
    if (fill.current) fill.current.intensity = 6 * l;
    strips.color.setScalar(1.6 * l);
    if (ring.current) ring.current.opacity = 0.35 * l;
  });

  return (
    <>
      <ambientLight intensity={0.06} />
      <spotLight
        ref={key} position={[2.5, 6.5, 3.5]} angle={0.55} penumbra={0.9} decay={2} castShadow={!low}
        shadow-mapSize={[1024, 1024]} shadow-bias={-0.0004} color="#fff4ea"
      />
      <spotLight ref={rim} position={[-5, 2.4, -3.5]} angle={0.6} penumbra={1} decay={2} color="#ff1f35" />
      <pointLight ref={fill} position={[5, 1.4, -4]} decay={2} color="#9fb3ff" />

      <Environment resolution={low ? 128 : 256} frames={1}>
        <Lightformer form="rect" intensity={3} position={[0, 5, 0]} rotation-x={Math.PI / 2} scale={[9, 2.2, 1]} />
        <Lightformer form="rect" intensity={1.2} position={[0, 2.5, -7]} scale={[12, 1.6, 1]} />
        <Lightformer form="rect" intensity={1.4} position={[-7, 2, 0]} rotation-y={Math.PI / 2} scale={[8, 1, 1]} />
        <Lightformer form="rect" color="#ff2236" intensity={2.4} position={[7, 1.4, 0]} rotation-y={-Math.PI / 2} scale={[8, 0.5, 1]} />
        <Lightformer form="ring" intensity={1.6} position={[3, 3, 5]} scale={2.4} onUpdate={(self) => self.lookAt(0, 0, 0)} />
      </Environment>

      {/* Overhead light strips (visible in the floor reflection) */}
      {[-1.6, 0, 1.6].map((z) => (
        <mesh key={z} position={[0, 4.6, z]} rotation-x={Math.PI / 2} material={strips}>
          <planeGeometry args={[6, 0.12]} />
        </mesh>
      ))}

      {/* Turntable ring */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.003, 0]}>
        <ringGeometry args={[3.05, 3.08, 128]} />
        <meshBasicMaterial ref={ring} color="#ff2a3d" transparent opacity={0.35} toneMapped={false} />
      </mesh>

      <mesh rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[80, 80]} />
        {low ? (
          <meshStandardMaterial color="#080809" roughness={0.6} metalness={0.4} />
        ) : (
          <MeshReflectorMaterial
            blur={[400, 120]} resolution={1024} mixBlur={1} mixStrength={14} roughness={0.85}
            depthScale={1.1} minDepthThreshold={0.4} maxDepthThreshold={1.3} color="#0a0a0b" metalness={0.55} mirror={0.55}
          />
        )}
      </mesh>
      <ContactShadows position={[0, 0.005, 0]} opacity={0.8} scale={9} blur={2.2} far={2.2} resolution={low ? 256 : 512} color="#000000" />
    </>
  );
}
