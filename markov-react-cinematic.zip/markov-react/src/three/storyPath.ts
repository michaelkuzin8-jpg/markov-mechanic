import type { ServiceKey } from '../data/site';

export interface Keyframe {
  yaw: number; // car rotation (radians), driven by scroll
  target: [number, number, number]; // look-at point in CAR-LOCAL coordinates (follows the car as it turns)
  offset: [number, number, number]; // camera offset from the target in WORLD space
  xray: number;
  focus: ServiceKey | null;
  spin: number;
  turbo: number;
}

const TAU = Math.PI * 2;

/** Chapter 0 = hero, 1-5 = services, 6 = outro. One keyframe per chapter. */
export const KEYFRAMES: Keyframe[] = [
  { yaw: 0.0, target: [0.1, 0.55, 0], offset: [5.4, 1.35, 4.9], xray: 0, focus: null, spin: 0, turbo: 0 },
  { yaw: 0.35, target: [1.2, 0.6, 0], offset: [2.0, 2.7, 2.5], xray: 0.9, focus: 'maintenance', spin: 0, turbo: 0 },
  { yaw: Math.PI + 0.64, target: [1.0, 0.62, -0.25], offset: [1.7, 2.1, 2.7], xray: 0.9, focus: 'diagnostics', spin: 0, turbo: 0 },
  { yaw: TAU + 0.3, target: [1.25, 0.4, 0.6], offset: [1.5, 0.55, 2.8], xray: 0.55, focus: 'brakes', spin: 1.6, turbo: 0 },
  { yaw: TAU + 0.9, target: [0.98, 0.55, 0.3], offset: [1.0, 1.9, 2.6], xray: 0.92, focus: 'turbo', spin: 0, turbo: 40 },
  { yaw: TAU + 2.36, target: [-0.8, 0.42, 0], offset: [3.7, 1.5, 3.9], xray: 0.55, focus: 'performance', spin: 7, turbo: 25 },
  { yaw: 2 * TAU + 0.05, target: [0.1, 0.5, 0], offset: [6.0, 2.0, 5.4], xray: 0, focus: null, spin: 0, turbo: 0 },
];

/** Intro opening shot: low and close on the nose / headlights. */
export const INTRO_FRAME: Keyframe = { yaw: -0.25, target: [2.0, 0.55, 0.2], offset: [2.4, 0.3, 1.1], xray: 0, focus: null, spin: 0, turbo: 0 };

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

export interface Pose {
  yaw: number; target: [number, number, number]; offset: [number, number, number];
  xray: number; spin: number; turbo: number; focus: ServiceKey | null;
}

const mix = (a: Keyframe, b: Keyframe, f: number): Pose => ({
  yaw: lerp(a.yaw, b.yaw, f),
  target: [lerp(a.target[0], b.target[0], f), lerp(a.target[1], b.target[1], f), lerp(a.target[2], b.target[2], f)],
  offset: [lerp(a.offset[0], b.offset[0], f), lerp(a.offset[1], b.offset[1], f), lerp(a.offset[2], b.offset[2], f)],
  xray: lerp(a.xray, b.xray, f),
  spin: lerp(a.spin, b.spin, f),
  turbo: lerp(a.turbo, b.turbo, f),
  focus: f < 0.5 ? a.focus : b.focus,
});

/**
 * Scroll progress (0..1) -> camera/car pose. Each chapter "dwells" for a while
 * (so text can be read) before an eased transition to the next.
 * With `snap` (reduced motion) the pose cuts between chapters instead of flying.
 */
export function poseAt(progress: number, snap = false): Pose {
  const n = KEYFRAMES.length - 1;
  const p = Math.min(Math.max(progress, 0), 1) * n;
  if (snap) return mix(KEYFRAMES[Math.round(p)], KEYFRAMES[Math.round(p)], 0);
  const i = Math.min(Math.floor(p), n - 1);
  const frac = p - i;
  const hold = 0.22;
  const f = ease(Math.min(Math.max((frac - hold) / (1 - 2 * hold), 0), 1));
  return mix(KEYFRAMES[i], KEYFRAMES[i + 1], f);
}

export const blendPose = (a: Pose, b: Pose, f: number): Pose => mix(a as Keyframe, b as Keyframe, f);

/** Rotate a car-local point by the car's yaw into world space. */
export function toWorld(local: [number, number, number], yaw: number): [number, number, number] {
  const c = Math.cos(yaw), s = Math.sin(yaw);
  return [local[0] * c + local[2] * s, local[1], -local[0] * s + local[2] * c];
}
