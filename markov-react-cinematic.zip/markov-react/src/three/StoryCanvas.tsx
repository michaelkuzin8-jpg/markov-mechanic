import { Suspense, useRef, useState } from 'react';
import * as THREE from 'three';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { PerformanceMonitor } from '@react-three/drei';
import CarModel from './CarModel';
import Studio from './Studio';
import { createCarState, damp } from './carState';
import { INTRO_FRAME, blendPose, poseAt, toWorld } from './storyPath';
import { intro } from '../lib/intro';

export interface StoryStore {
  progress: number; // 0..1 from ScrollTrigger
  px: number; // pointer -1..1
  py: number;
}

function Rig({ story, car, reduced }: { story: StoryStore; car: ReturnType<typeof createCarState>; reduced: boolean }) {
  const { camera, size } = useThree();
  const s = useRef({ p: story.progress, cam: intro.cam, px: 0, py: 0, idle: 0 });
  const look = useRef(new THREE.Vector3());

  useFrame((state, delta) => {
    const dt = Math.min(delta, 1 / 20);
    const v = s.current;
    // Scroll is already a direct user input; light damping keeps it silky without lag.
    v.p = reduced ? story.progress : damp(v.p, story.progress, 6, dt);
    v.cam = damp(v.cam, intro.cam, 3.2, dt);
    v.px = damp(v.px, reduced ? 0 : story.px, 3, dt);
    v.py = damp(v.py, reduced ? 0 : story.py, 3, dt);

    let pose = poseAt(v.p, reduced);
    if (v.cam < 0.999) {
      const e = v.cam * v.cam * (3 - 2 * v.cam);
      pose = blendPose(INTRO_FRAME, pose, e);
    }
    // Idle breathing so the hero never feels frozen (disabled for reduced motion)
    const t = state.clock.elapsedTime;
    const idleYaw = reduced ? 0 : Math.sin(t * 0.25) * 0.06 * (1 - Math.min(v.p * 8, 1));

    car.yaw = pose.yaw + idleYaw;
    car.xray = pose.xray;
    car.spin = pose.spin;
    car.turbo = pose.turbo;
    car.focus = pose.focus;
    car.light = intro.light;

    // Portrait screens: pull the camera back so the car fits
    const aspect = size.width / size.height;
    const pull = aspect < 1 ? 1 + (1 - aspect) * 2.1 : 1;
    const [tx, ty, tz] = toWorld(pose.target, car.yaw);
    camera.position.set(
      tx + pose.offset[0] * pull + v.px * 0.35,
      ty + pose.offset[1] * (aspect < 1 ? 1.15 : 1) + v.py * 0.2,
      tz + pose.offset[2] * pull - v.px * 0.2,
    );
    look.current.set(tx, ty, tz);
    camera.lookAt(look.current);

    // Frame the car beside the copy: right of centre on wide screens, above it on phones.
    const shiftX = aspect >= 1 ? -size.width * 0.16 : 0;
    const shiftY = aspect < 1 ? size.height * 0.25 : 0;
    const view = (camera as THREE.PerspectiveCamera).view;
    if (!view || view.offsetX !== shiftX || view.offsetY !== shiftY || view.fullWidth !== size.width || view.fullHeight !== size.height) {
      (camera as THREE.PerspectiveCamera).setViewOffset(size.width, size.height, shiftX, shiftY, size.width, size.height);
    }
  });
  return null;
}

export default function StoryCanvas({ story, low, reduced, active }: { story: StoryStore; low: boolean; reduced: boolean; active: boolean }) {
  const [car] = useState(() => createCarState({ light: intro.light }));
  const [dpr, setDpr] = useState<number>(low ? 1.25 : Math.min(window.devicePixelRatio, 1.75));

  return (
    <Canvas
      frameloop={active ? 'always' : 'never'}
      shadows={!low}
      dpr={dpr}
      camera={{ fov: 32, near: 0.1, far: 60, position: [5.4, 1.9, 4.9] }}
      gl={{ antialias: !low, powerPreference: 'high-performance', toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.05 }}
      onCreated={({ camera, gl }) => {
        gl.setClearColor('#050505');
        if (import.meta.env.DEV || /[?&]debug\b/.test(location.search)) {
          (window as unknown as Record<string, unknown>).__markovStory = { camera, car, story };
        }
      }}
      aria-hidden
    >
      <color attach="background" args={['#050505']} />
      <fog attach="fog" args={['#050505', 10, 26]} />
      <PerformanceMonitor onDecline={() => setDpr(1)} />
      <Suspense fallback={null}>
        <Studio state={car} low={low} />
        <CarModel state={car} low={low} />
      </Suspense>
      <Rig story={story} car={car} reduced={reduced} />
    </Canvas>
  );
}
