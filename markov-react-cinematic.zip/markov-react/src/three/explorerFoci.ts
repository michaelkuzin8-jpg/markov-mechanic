import type { ServiceKey } from '../data/site';

type V3 = [number, number, number];
export interface Focus { hotspot: V3; normal: V3; target: V3; cam: V3; xray: number; spin: number; turbo: number }

/** Camera stops for the interactive explorer (car is fixed at yaw 0; the visitor orbits). */
export const FOCI: Record<ServiceKey, Focus> = {
  maintenance: { hotspot: [1.44, 0.84, 0.12], normal: [0.2, 1, 0.3], target: [1.2, 0.6, 0], cam: [2.9, 2.5, 2.2], xray: 0.9, spin: 0, turbo: 0 },
  diagnostics: { hotspot: [0.9, 0.72, -0.5], normal: [0, 0.8, -1], target: [1.0, 0.6, -0.3], cam: [1.4, 2.2, -2.9], xray: 0.9, spin: 0, turbo: 0 },
  brakes: { hotspot: [1.25, 0.72, 0.95], normal: [0, 0.3, 1], target: [1.25, 0.4, 0.7], cam: [2.5, 0.75, 3.0], xray: 0.5, spin: 1.2, turbo: 0 },
  turbo: { hotspot: [0.98, 0.72, 0.46], normal: [0, 1, 0.6], target: [1.0, 0.55, 0.35], cam: [1.2, 2.0, 2.6], xray: 0.92, spin: 0, turbo: 40 },
  performance: { hotspot: [-2.25, 0.3, 0.3], normal: [-1, 0.2, 0.3], target: [-1.3, 0.38, 0], cam: [-4.4, 1.3, 3.0], xray: 0.55, spin: 5, turbo: 20 },
};

export const HOME_VIEW = { cam: [4.7, 1.9, 4.5] as V3, target: [0, 0.5, 0] as V3 };
