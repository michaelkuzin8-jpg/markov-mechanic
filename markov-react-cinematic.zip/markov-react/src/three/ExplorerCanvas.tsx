import { Suspense, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Html, OrbitControls, PerformanceMonitor } from '@react-three/drei';
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib';
import gsap from 'gsap';
import CarModel from './CarModel';
import Studio from './Studio';
import { createCarState, type CarState } from './carState';
import { FOCI, HOME_VIEW } from './explorerFoci';
import { SERVICES, type ServiceKey } from '../data/site';

export interface ExplorerApi { zoom: (dir: 1 | -1) => void; reset: () => void }

interface Props {
  focus: ServiceKey | null;
  onFocus: (k: ServiceKey) => void;
  xray: boolean;
  autoRotate: boolean;
  zoomEnabled: boolean;
  low: boolean;
  reduced: boolean;
  active: boolean;
  apiRef: React.MutableRefObject<ExplorerApi | null>;
}

const MIN_D = 1.6;
const MAX_D = 11;

function Director({ focus, xray, car, reduced, apiRef }: { focus: ServiceKey | null; xray: boolean; car: CarState; reduced: boolean; apiRef: Props['apiRef'] }) {
  const { camera, controls } = useThree();
  const ctl = controls as unknown as OrbitControlsImpl | null;

  // Animated camera focus transitions
  useEffect(() => {
    if (!ctl) return;
    const stop = focus ? FOCI[focus] : { cam: HOME_VIEW.cam, target: HOME_VIEW.target };
    // Pull focus shots back a little so the part sits in context
    const k = focus ? 1.22 : 1;
    const cam = stop.cam.map((c, i) => stop.target[i] + (c - stop.target[i]) * k);
    const d = reduced ? 0 : 1.6;
    const tl = gsap.timeline({ defaults: { duration: d, ease: 'power3.inOut' }, onUpdate: () => ctl.update() });
    tl.to(camera.position, { x: cam[0], y: cam[1], z: cam[2] }, 0)
      .to(ctl.target, { x: stop.target[0], y: stop.target[1], z: stop.target[2] }, 0);
    return () => { tl.kill(); };
  }, [focus, ctl, camera, reduced]);

  useEffect(() => {
    if (!ctl) return;
    apiRef.current = {
      zoom: (dir) => {
        const off = camera.position.clone().sub(ctl.target);
        const len = THREE.MathUtils.clamp(off.length() * (dir > 0 ? 0.72 : 1.38), MIN_D, MAX_D);
        off.setLength(len).add(ctl.target);
        gsap.to(camera.position, { x: off.x, y: off.y, z: off.z, duration: reduced ? 0 : 0.6, ease: 'power3.out', onUpdate: () => ctl.update() });
      },
      reset: () => {
        gsap.to(camera.position, { x: HOME_VIEW.cam[0], y: HOME_VIEW.cam[1], z: HOME_VIEW.cam[2], duration: reduced ? 0 : 1.2, ease: 'power3.inOut', onUpdate: () => ctl.update() });
        gsap.to(ctl.target, { x: HOME_VIEW.target[0], y: HOME_VIEW.target[1], z: HOME_VIEW.target[2], duration: reduced ? 0 : 1.2, ease: 'power3.inOut' });
      },
    };
    return () => { apiRef.current = null; };
  }, [ctl, camera, reduced, apiRef]);

  const shift = useRef({ x: 0, y: 0 });
  useFrame(({ size }, delta) => {
    // Slide the framing away from the detail panel (right on desktop, bottom on phones)
    const wide = size.width / size.height >= 1 && size.width > 900;
    const tx = focus && wide ? size.width * 0.17 : 0;
    const ty = focus && !wide ? size.height * 0.2 : 0;
    const a = 1 - Math.exp(-5 * Math.min(delta, 0.05));
    shift.current.x += (tx - shift.current.x) * a;
    shift.current.y += (ty - shift.current.y) * a;
    (camera as THREE.PerspectiveCamera).setViewOffset(size.width, size.height, shift.current.x, shift.current.y, size.width, size.height);

    const f = focus ? FOCI[focus] : null;
    car.focus = focus;
    car.xray = xray ? 0.9 : f ? f.xray : 0;
    car.spin = f ? f.spin : 0;
    car.turbo = f ? f.turbo : 0;
  });
  return null;
}

function Hotspots({ focus, onFocus }: { focus: ServiceKey | null; onFocus: (k: ServiceKey) => void }) {
  const { camera } = useThree();
  const els = useRef<Partial<Record<ServiceKey, HTMLButtonElement | null>>>({});
  const tmp = useRef(new THREE.Vector3());
  const nrm = useRef(new THREE.Vector3());

  // Fade hotspots that face away from the camera so labels don't float through the car
  useFrame(() => {
    for (const s of SERVICES) {
      const el = els.current[s.key];
      if (!el) continue;
      const f = FOCI[s.key];
      tmp.current.set(...f.hotspot);
      const toCam = camera.position.clone().sub(tmp.current).normalize();
      nrm.current.set(...f.normal).normalize();
      const facing = toCam.dot(nrm.current);
      const o = THREE.MathUtils.clamp((facing + 0.35) / 0.5, 0.18, 1);
      el.style.opacity = String(focus === s.key ? 1 : o);
      el.style.pointerEvents = o < 0.3 && focus !== s.key ? 'none' : 'auto';
    }
  });

  return (
    <>
      {SERVICES.map((s, i) => (
        <Html key={s.key} position={FOCI[s.key].hotspot} center zIndexRange={[30, 0]}>
          <button
            ref={(el) => { els.current[s.key] = el; }}
            type="button"
            className={`hotspot ${focus === s.key ? 'on' : ''}`}
            onClick={(e) => { e.stopPropagation(); onFocus(s.key); }}
            aria-label={`Focus on ${s.title}`}
            aria-pressed={focus === s.key}
          >
            <span className="hs-ring" aria-hidden><span className="hs-num mono">{i + 1}</span></span>
            <span className="hs-label mono">{s.title}</span>
          </button>
        </Html>
      ))}
    </>
  );
}

export default function ExplorerCanvas(props: Props) {
  const { focus, onFocus, xray, autoRotate, zoomEnabled, low, reduced, active, apiRef } = props;
  const [car] = useState(() => createCarState());
  const [dpr, setDpr] = useState<number>(low ? 1.25 : Math.min(window.devicePixelRatio, 1.75));

  return (
    <Canvas
      frameloop={active ? 'always' : 'never'}
      shadows={!low}
      dpr={dpr}
      camera={{ fov: 34, near: 0.1, far: 60, position: HOME_VIEW.cam }}
      gl={{ antialias: !low, powerPreference: 'high-performance', toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.08 }}
      onCreated={({ camera }) => {
        if (import.meta.env.DEV || /[?&]debug\b/.test(location.search)) {
          (window as unknown as Record<string, unknown>).__markovExplorer = { camera, car };
        }
      }}
    >
      <color attach="background" args={['#070708']} />
      <fog attach="fog" args={['#070708', 11, 28]} />
      <PerformanceMonitor onDecline={() => setDpr(1)} />
      <Suspense fallback={null}>
        <Studio state={car} low={low} />
        <CarModel state={car} low={low} />
        <Hotspots focus={focus} onFocus={onFocus} />
      </Suspense>
      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        enablePan={false}
        enableZoom={zoomEnabled}
        minDistance={MIN_D}
        maxDistance={MAX_D}
        minPolarAngle={0.15}
        maxPolarAngle={Math.PI / 2 - 0.04}
        autoRotate={autoRotate && !focus && !reduced}
        autoRotateSpeed={0.7}
        target={HOME_VIEW.target}
      />
      <Director focus={focus} xray={xray} car={car} reduced={reduced} apiRef={apiRef} />
    </Canvas>
  );
}
