/**
 * PROCEDURAL DEMONSTRATION MODEL
 * A stylised sports coupe built entirely from code (extruded profiles, lathes, tubes).
 * It is an illustrative stand-in, not a model of any real or specific car.
 * Component groups (engine, turbo, brakes, suspension, exhaust...) can be highlighted
 * so the scene can explain each Markov Auto service.
 */
import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { RoundedBox } from '@react-three/drei';
import type { ServiceKey } from '../data/site';
import { damp, type CarState } from './carState';

const KEYS: ServiceKey[] = ['maintenance', 'diagnostics', 'brakes', 'turbo', 'performance'];
const HIGHLIGHT = new THREE.Color('#ff2a3d');

const WHEEL_R = 0.335;
const TRACK = 0.76;
const AXLE = 1.25;

class Helix extends THREE.Curve<THREE.Vector3> {
  constructor(private r: number, private h: number, private turns: number) { super(); }
  getPoint(t: number, target = new THREE.Vector3()) {
    const a = t * Math.PI * 2 * this.turns;
    return target.set(Math.cos(a) * this.r, t * this.h - this.h / 2, Math.sin(a) * this.r);
  }
}

const tube = (pts: [number, number, number][], radius: number, seg = 48) =>
  new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p))), seg, radius, 10, false);

function useCarGeometry() {
  const geo = useMemo(() => {
    // Lower body side profile (x = length, front is +x), extruded across the width.
    const s = new THREE.Shape();
    s.moveTo(-2.12, 0.3);
    s.lineTo(-2.2, 0.55);
    s.quadraticCurveTo(-2.2, 0.86, -1.95, 0.9);
    s.lineTo(-1.2, 0.93);
    s.lineTo(0.85, 0.9);
    s.quadraticCurveTo(1.7, 0.86, 2.05, 0.72);
    s.quadraticCurveTo(2.26, 0.62, 2.22, 0.42);
    s.lineTo(2.1, 0.24);
    s.lineTo(AXLE + 0.43, 0.24);
    s.absarc(AXLE, 0.26, 0.43, 0, Math.PI, false);
    s.lineTo(-AXLE + 0.43, 0.22);
    s.absarc(-AXLE, 0.26, 0.43, 0, Math.PI, false);
    s.lineTo(-2.0, 0.24);
    s.lineTo(-2.12, 0.3);
    const body = new THREE.ExtrudeGeometry(s, {
      depth: 1.4, bevelEnabled: true, bevelThickness: 0.12, bevelSize: 0.1, bevelOffset: -0.1, bevelSegments: 6, curveSegments: 28,
    });
    body.translate(0, 0, -0.7);
    body.computeVertexNormals();

    const c = new THREE.Shape();
    c.moveTo(-1.55, 0.9);
    c.quadraticCurveTo(-0.95, 1.2, -0.35, 1.25);
    c.lineTo(0.1, 1.25);
    c.quadraticCurveTo(0.45, 1.22, 0.98, 0.9);
    c.lineTo(-1.55, 0.9);
    const cabin = new THREE.ExtrudeGeometry(c, {
      depth: 1.0, bevelEnabled: true, bevelThickness: 0.1, bevelSize: 0.08, bevelOffset: -0.08, bevelSegments: 5, curveSegments: 24,
    });
    cabin.translate(0, 0, -0.5);

    const bodyEdges = new THREE.EdgesGeometry(body, 24);
    const cabinEdges = new THREE.EdgesGeometry(cabin, 24);

    // Tyre: lathe of a rounded sidewall profile, axis rotated to Z
    const prof = [
      [0.245, -0.12], [0.3, -0.125], [0.325, -0.11], [WHEEL_R, -0.06], [WHEEL_R, 0.06], [0.325, 0.11], [0.3, 0.125], [0.245, 0.12],
    ].map(([x, y]) => new THREE.Vector2(x, y));
    const tyre = new THREE.LatheGeometry(prof, 56);
    tyre.rotateX(Math.PI / 2);

    const spring = new THREE.TubeGeometry(new Helix(0.06, 0.3, 6), 160, 0.011, 8, false);

    const exhaust = tube([[0.98, 0.42, 0.36], [0.82, 0.22, 0.3], [0.2, 0.17, 0.3], [-1.0, 0.17, 0.25], [-1.62, 0.2, 0.05]], 0.04, 80);
    const manifold = [0, 1, 2, 3].map((i) => tube([[0.96 + i * 0.13, 0.5, 0.2], [0.98 + i * 0.1, 0.48, 0.3], [1.0, 0.47, 0.34]], 0.017, 16));
    const pipeHot = tube([[1.02, 0.6, 0.42], [1.35, 0.64, 0.46], [1.8, 0.48, 0.46], [2.0, 0.4, 0.38]], 0.034, 48);
    const pipeCold = tube([[2.0, 0.4, -0.38], [1.8, 0.52, -0.43], [1.55, 0.66, -0.36], [1.38, 0.64, -0.28]], 0.034, 48);
    const harness = tube([[0.9, 0.64, -0.5], [1.0, 0.8, -0.22], [1.3, 0.82, 0.02], [1.55, 0.79, 0.15]], 0.012, 48);
    const harness2 = tube([[0.92, 0.63, -0.46], [1.2, 0.6, -0.3], [1.6, 0.62, -0.42]], 0.01, 32);
    const disc = new THREE.CylinderGeometry(0.2, 0.2, 0.026, 40);
    disc.rotateX(Math.PI / 2);
    const caliper = new THREE.TorusGeometry(0.2, 0.045, 10, 18, 1.15);
    const barrel = new THREE.CylinderGeometry(0.246, 0.246, 0.2, 40, 1, true);
    barrel.rotateX(Math.PI / 2);
    const hub = new THREE.CylinderGeometry(0.06, 0.06, 0.04, 20);
    hub.rotateX(Math.PI / 2);
    return { body, cabin, bodyEdges, cabinEdges, tyre, spring, exhaust, manifold, pipeHot, pipeCold, harness, harness2, disc, caliper, barrel, hub };
  }, []);

  useEffect(() => () => {
    Object.values(geo).forEach((g) => (Array.isArray(g) ? g.forEach((x) => x.dispose()) : g.dispose()));
  }, [geo]);
  return geo;
}

function useCarMaterials() {
  const mats = useMemo(() => {
    const std = (p: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(p);
    const m = {
      paint: new THREE.MeshPhysicalMaterial({ color: '#9b0b1d', metalness: 0.6, roughness: 0.26, clearcoat: 1, clearcoatRoughness: 0.05, transparent: true }),
      glass: new THREE.MeshPhysicalMaterial({ color: '#07090c', metalness: 0.3, roughness: 0.04, clearcoat: 1, transparent: true, opacity: 0.82 }),
      edge: new THREE.LineBasicMaterial({ color: '#ff4458', transparent: true, opacity: 0, depthWrite: false }),
      trim: std({ color: '#0c0c0e', roughness: 0.55, metalness: 0.35 }),
      carbon: std({ color: '#151518', roughness: 0.35, metalness: 0.6 }),
      rubber: std({ color: '#0f0f10', roughness: 0.9, metalness: 0 }),
      rim: new THREE.MeshPhysicalMaterial({ color: '#b8bcc3', metalness: 1, roughness: 0.2, clearcoat: 0.6, side: THREE.DoubleSide }),
      darkMetal: std({ color: '#2a2b2f', roughness: 0.42, metalness: 0.85 }),
      alu: std({ color: '#c6c9ce', roughness: 0.3, metalness: 1 }),
      head: std({ color: '#ffffff', emissive: '#ffffff', emissiveIntensity: 0, roughness: 0.2 }),
      tail: std({ color: '#300006', emissive: '#ff1030', emissiveIntensity: 0, roughness: 0.3 }),
      scan: new THREE.MeshBasicMaterial({ color: '#ff2a3d', transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }),
      // Highlightable component materials
      valveCover: std({ color: '#b06a3a', roughness: 0.28, metalness: 1 }),
      oilCap: std({ color: '#d9a400', roughness: 0.4, metalness: 0.2 }),
      reservoir: std({ color: '#d7d7d2', roughness: 0.3, metalness: 0, transparent: true, opacity: 0.85 }),
      oilFilter: std({ color: '#1e3a8a', roughness: 0.45, metalness: 0.4 }),
      ecu: std({ color: '#1b1c20', roughness: 0.5, metalness: 0.6 }),
      wire: std({ color: '#26272b', roughness: 0.7, metalness: 0.1 }),
      caliper: std({ color: '#c8102e', roughness: 0.35, metalness: 0.3 }),
      disc: std({ color: '#8d9096', roughness: 0.35, metalness: 0.9 }),
      coil: std({ color: '#c9a227', roughness: 0.3, metalness: 0.8 }),
      arm: std({ color: '#36383d', roughness: 0.5, metalness: 0.8 }),
      turbo: std({ color: '#9a9ca1', roughness: 0.35, metalness: 1 }),
      hose: std({ color: '#1f4fd6', roughness: 0.45, metalness: 0.1 }),
      exhaust: std({ color: '#7a7d83', roughness: 0.3, metalness: 1 }),
      intercooler: std({ color: '#b9bdc4', roughness: 0.38, metalness: 1 }),
      filter: std({ color: '#c8102e', roughness: 0.8, metalness: 0 }),
    };
    const groups: Record<ServiceKey, THREE.MeshStandardMaterial[]> = {
      maintenance: [m.valveCover, m.oilCap, m.reservoir, m.oilFilter],
      diagnostics: [m.ecu, m.wire],
      brakes: [m.caliper, m.disc, m.coil, m.arm],
      turbo: [m.turbo, m.hose],
      performance: [m.exhaust, m.intercooler, m.filter],
    };
    Object.values(groups).flat().forEach((mat) => mat.emissive.copy(HIGHLIGHT));
    return { m, groups };
  }, []);

  useEffect(() => () => { Object.values(mats.m).forEach((x) => x.dispose()); }, [mats]);
  return mats;
}

function Wheel({ position, mirror, g, m, spinRef }: {
  position: [number, number, number]; mirror: boolean; g: ReturnType<typeof useCarGeometry>;
  m: ReturnType<typeof useCarMaterials>['m']; spinRef: (el: THREE.Group | null) => void;
}) {
  return (
    <group position={position} scale={[1, 1, mirror ? -1 : 1]}>
      {/* brake hardware does not rotate with the wheel */}
      <mesh geometry={g.disc} material={m.disc} position={[0, 0, -0.03]} castShadow />
      <mesh geometry={g.caliper} material={m.caliper} position={[0, 0, -0.005]} rotation={[0, 0, 0.35]} />
      <group ref={spinRef}>
        <mesh geometry={g.tyre} material={m.rubber} castShadow receiveShadow />
        <mesh geometry={g.barrel} material={m.rim} />
        {[0, 1, 2, 3, 4].map((i) => (
          <mesh key={i} material={m.rim} position={[Math.cos((i / 5) * Math.PI * 2) * 0.125, Math.sin((i / 5) * Math.PI * 2) * 0.125, 0.075]} rotation={[0, 0, (i / 5) * Math.PI * 2]}>
            <boxGeometry args={[0.23, 0.045, 0.03]} />
          </mesh>
        ))}
        <mesh geometry={g.hub} material={m.alu} position={[0, 0, 0.085]} />
      </group>
    </group>
  );
}

function Coilover({ position, g, m }: { position: [number, number, number]; g: ReturnType<typeof useCarGeometry>; m: ReturnType<typeof useCarMaterials>['m'] }) {
  return (
    <group position={position} rotation={[position[2] > 0 ? 0.12 : -0.12, 0, 0]}>
      <mesh geometry={g.spring} material={m.coil} />
      <mesh material={m.arm}><cylinderGeometry args={[0.028, 0.028, 0.44, 14]} /></mesh>
      <mesh material={m.coil} position={[0, 0.17, 0]}><cylinderGeometry args={[0.072, 0.072, 0.02, 20]} /></mesh>
    </group>
  );
}

export default function CarModel({ state, low = false }: { state: CarState; low?: boolean }) {
  const g = useCarGeometry();
  const { m, groups } = useCarMaterials();
  const root = useRef<THREE.Group>(null);
  const wheels = useRef<(THREE.Group | null)[]>([]);
  const compressor = useRef<THREE.Group>(null);
  const scan = useRef<THREE.Mesh>(null);
  const ecuLed = useRef<THREE.MeshStandardMaterial>(null);
  const cur = useRef({ xray: state.xray, light: state.light, yaw: state.yaw, hl: Object.fromEntries(KEYS.map((k) => [k, 0])) as Record<ServiceKey, number> });

  useFrame((s, delta) => {
    const dt = Math.min(delta, 1 / 20);
    const c = cur.current;
    const t = s.clock.elapsedTime;
    c.xray = damp(c.xray, state.xray, 5, dt);
    c.light = damp(c.light, state.light, 4, dt);
    c.yaw = damp(c.yaw, state.yaw, 4, dt);
    if (root.current) root.current.rotation.y = c.yaw;

    // X-ray: fade the paint, fade in the red wireframe edges
    m.paint.opacity = 1 - 0.9 * c.xray;
    m.paint.depthWrite = c.xray < 0.04;
    m.glass.opacity = 0.82 * (1 - 0.85 * c.xray);
    m.glass.depthWrite = c.xray < 0.04;
    m.edge.opacity = 0.75 * c.xray;

    // Lights (intro reveal flickers the headlights on)
    const flicker = c.light < 0.98 ? (Math.sin(t * 40) > 0.2 ? 1 : 0.35) : 1;
    m.head.emissiveIntensity = 3.2 * Math.pow(c.light, 2) * flicker;
    m.tail.emissiveIntensity = 2.4 * c.light;

    // Component highlights
    for (const k of KEYS) {
      c.hl[k] = damp(c.hl[k], state.focus === k ? 1 : 0, 6, dt);
      const pulse = c.hl[k] * (0.75 + 0.35 * Math.sin(t * 4.2));
      for (const mat of groups[k]) mat.emissiveIntensity = pulse * 1.1;
    }

    wheels.current.forEach((w) => { if (w) w.rotation.z -= state.spin * dt; });
    if (compressor.current) compressor.current.rotation.z += state.turbo * dt;

    if (scan.current) {
      const on = c.hl.diagnostics;
      m.scan.opacity = 0.32 * on;
      scan.current.visible = on > 0.01;
      scan.current.position.x = 0.82 + ((t * 0.45) % 1) * 0.95;
    }
    if (ecuLed.current) ecuLed.current.emissiveIntensity = c.hl.diagnostics > 0.05 ? (Math.sin(t * 12) > 0 ? 4 : 0.4) : 0.6;
  });

  const setWheel = (i: number) => (el: THREE.Group | null) => { wheels.current[i] = el; };
  const cast = !low;

  return (
    <group ref={root} dispose={null}>
      {/* Body shell + cabin */}
      <mesh geometry={g.body} material={m.paint} castShadow={cast} renderOrder={2} />
      <mesh geometry={g.cabin} material={m.glass} castShadow={cast} renderOrder={3} />
      <lineSegments geometry={g.bodyEdges} material={m.edge} renderOrder={4} />
      <lineSegments geometry={g.cabinEdges} material={m.edge} renderOrder={4} />

      {/* Exterior details */}
      <mesh material={m.carbon} position={[2.15, 0.225, 0]}><boxGeometry args={[0.3, 0.02, 1.5]} /></mesh>
      <mesh material={m.trim} position={[2.2, 0.36, 0]}><boxGeometry args={[0.05, 0.13, 0.86]} /></mesh>
      {[-1, 1].map((sd) => (
        <group key={sd}>
          <RoundedBox args={[0.06, 0.05, 0.36]} radius={0.02} position={[2.1, 0.66, sd * 0.5]} rotation={[0, 0, -0.5]} material={m.head} />
          <RoundedBox args={[0.14, 0.07, 0.04]} radius={0.02} position={[0.82, 0.98, sd * 0.79]} material={m.paint} />
          <mesh material={m.carbon} position={[-1.98, 1.06, sd * 0.55]}><boxGeometry args={[0.08, 0.14, 0.03]} /></mesh>
        </group>
      ))}
      <mesh material={m.tail} position={[-2.2, 0.7, 0]}><boxGeometry args={[0.03, 0.045, 1.3]} /></mesh>
      <mesh material={m.carbon} position={[-2.0, 1.14, 0]}><boxGeometry args={[0.28, 0.025, 1.56]} /></mesh>

      {/* Wheels with brakes */}
      <Wheel position={[AXLE, WHEEL_R, TRACK]} mirror={false} g={g} m={m} spinRef={setWheel(0)} />
      <Wheel position={[AXLE, WHEEL_R, -TRACK]} mirror g={g} m={m} spinRef={setWheel(1)} />
      <Wheel position={[-AXLE, WHEEL_R, TRACK]} mirror={false} g={g} m={m} spinRef={setWheel(2)} />
      <Wheel position={[-AXLE, WHEEL_R, -TRACK]} mirror g={g} m={m} spinRef={setWheel(3)} />

      {/* Suspension */}
      {[AXLE, -AXLE].map((x) => [0.54, -0.54].map((z) => (
        <group key={`${x}${z}`}>
          <Coilover position={[x, 0.56, z]} g={g} m={m} />
          <mesh material={m.arm} position={[x, 0.3, z * 0.62]}><boxGeometry args={[0.07, 0.03, 0.62]} /></mesh>
          <mesh material={m.arm} position={[x, 0.62, z * 0.72]}><boxGeometry args={[0.05, 0.025, 0.42]} /></mesh>
        </group>
      )))}

      {/* Engine */}
      <group>
        <RoundedBox args={[0.6, 0.32, 0.42]} radius={0.03} position={[1.22, 0.5, 0]} material={m.darkMetal} />
        <RoundedBox args={[0.58, 0.07, 0.24]} radius={0.025} position={[1.22, 0.69, 0.04]} material={m.valveCover} />
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} material={m.trim} position={[1.04 + i * 0.12, 0.76, 0.04]}><cylinderGeometry args={[0.022, 0.022, 0.07, 12]} /></mesh>
        ))}
        <mesh material={m.oilCap} position={[1.44, 0.74, 0.12]}><cylinderGeometry args={[0.032, 0.032, 0.03, 18]} /></mesh>
        <mesh material={m.oilFilter} position={[1.2, 0.36, 0.25]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.045, 0.045, 0.1, 18]} /></mesh>
        <RoundedBox args={[0.5, 0.1, 0.1]} radius={0.03} position={[1.2, 0.62, -0.28]} material={m.alu} />
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} material={m.alu} position={[1.02 + i * 0.12, 0.56, -0.22]} rotation={[0.5, 0, 0]}><cylinderGeometry args={[0.022, 0.022, 0.14, 12]} /></mesh>
        ))}
        <mesh material={m.reservoir} position={[1.66, 0.64, -0.46]}><cylinderGeometry args={[0.05, 0.05, 0.11, 20]} /></mesh>
        <RoundedBox args={[0.2, 0.14, 0.13]} radius={0.015} position={[1.72, 0.56, 0.46]} material={m.trim} />
        {/* Cooling stack */}
        <mesh material={m.trim} position={[1.9, 0.48, 0]}><boxGeometry args={[0.05, 0.3, 0.72]} /></mesh>
        <mesh material={m.intercooler} position={[2.03, 0.4, 0]}><boxGeometry args={[0.06, 0.24, 0.86]} /></mesh>
        {/* Charge piping */}
        <mesh geometry={g.pipeHot} material={m.hose} />
        <mesh geometry={g.pipeCold} material={m.hose} />
        {/* Turbo */}
        <group position={[0.98, 0.52, 0.38]}>
          <mesh material={m.turbo} rotation={[0, 0, 0]}><torusGeometry args={[0.085, 0.05, 14, 28]} /></mesh>
          <mesh material={m.turbo} position={[0, 0, -0.07]}><torusGeometry args={[0.07, 0.045, 14, 28]} /></mesh>
          <mesh material={m.darkMetal} position={[0, 0, -0.035]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.05, 0.05, 0.05, 16]} /></mesh>
          <group ref={compressor} position={[0, 0, 0.02]}>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <mesh key={i} material={m.alu} rotation={[0, 0, (i / 6) * Math.PI * 2]} position={[Math.cos((i / 6) * Math.PI * 2) * 0.025, Math.sin((i / 6) * Math.PI * 2) * 0.025, 0]}>
                <boxGeometry args={[0.05, 0.008, 0.02]} />
              </mesh>
            ))}
          </group>
          <mesh material={m.filter} position={[0, 0.03, 0.14]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.05, 0.075, 0.12, 20]} /></mesh>
        </group>
        {g.manifold.map((geo, i) => <mesh key={i} geometry={geo} material={m.exhaust} />)}
        {/* Electronics */}
        <RoundedBox args={[0.16, 0.04, 0.12]} radius={0.01} position={[0.9, 0.62, -0.5]} material={m.ecu} />
        <mesh position={[0.97, 0.645, -0.46]}><sphereGeometry args={[0.009, 8, 8]} /><meshStandardMaterial ref={ecuLed} color="#300" emissive="#ff2a3d" emissiveIntensity={0.6} /></mesh>
        <mesh geometry={g.harness} material={m.wire} />
        <mesh geometry={g.harness2} material={m.wire} />
        <mesh ref={scan} material={m.scan} position={[1.2, 0.6, 0]} rotation={[0, Math.PI / 2, 0]} visible={false}><planeGeometry args={[1.1, 0.5]} /></mesh>
      </group>
      {/* Exhaust */}
      <mesh geometry={g.exhaust} material={m.exhaust} />
      <RoundedBox args={[0.42, 0.14, 0.7]} radius={0.04} position={[-1.82, 0.22, 0]} material={m.exhaust} />
      {[-0.3, 0.3].map((z) => (
        <mesh key={z} material={m.exhaust} position={[-2.1, 0.25, z]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.05, 0.05, 0.2, 20, 1, true]} /></mesh>
      ))}
    </group>
  );
}
