import type { ServiceKey } from '../data/site';

/**
 * Mutable state shared between DOM (GSAP / ScrollTrigger / buttons) and the 3D scene.
 * Written from outside React's render cycle and read every frame, so scrolling never
 * triggers React re-renders.
 */
export interface CarState {
  focus: ServiceKey | null; // which component group glows
  xray: number; // 0 = solid paint, 1 = see-through body with wireframe edges
  spin: number; // wheel spin speed (rad/s)
  turbo: number; // compressor wheel speed (rad/s)
  light: number; // 0..1 master light level (intro lighting reveal)
  yaw: number; // extra car rotation around Y (radians)
}

export const createCarState = (overrides: Partial<CarState> = {}): CarState => ({
  focus: null,
  xray: 0,
  spin: 0,
  turbo: 0,
  light: 1,
  yaw: 0,
  ...overrides,
});

/** Frame-rate independent exponential smoothing. */
export const damp = (current: number, target: number, lambda: number, dt: number) =>
  current + (target - current) * (1 - Math.exp(-lambda * dt));
