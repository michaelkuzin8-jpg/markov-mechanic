import { useRef } from 'react';
import { Link } from 'react-router';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import ScrollStory from '../components/ScrollStory';
import ClipImage from '../components/ClipImage';
import { ScrubText, Steps } from '../components/ScrollFx';
import { PROJECTS } from '../data/site';
import { imgSet, imgSrc, imgSize, prefersReducedMotion } from '../lib/hooks';

gsap.registerPlugin(ScrollTrigger);
const FEATURED = ['miata-engine-bay', 'c8-corvette', 'classic-corvette', 'audi-b8-coupe'].map((id) => PROJECTS.find((p) => p.id === id)!);

/** Sticky stack: each project card pins, then scales back and darkens as the next one slides over it. */
function ProjectStack() {
  const root = useRef<HTMLElement>(null);
  useGSAP(() => {
    if (prefersReducedMotion()) return;
    const cards = gsap.utils.toArray<HTMLElement>('.stack-card');
    cards.forEach((card, i) => {
      if (i === cards.length - 1) return;
      gsap.to(card.querySelector('.stack-inner'), {
        scale: 0.88, filter: 'brightness(0.35)', ease: 'none',
        scrollTrigger: { trigger: cards[i + 1], start: 'top bottom', end: 'top top', scrub: true },
      });
    });
    cards.forEach((card) => {
      gsap.fromTo(card.querySelector('img'), { scale: 1.2 }, { scale: 1, ease: 'none', scrollTrigger: { trigger: card, start: 'top bottom', end: 'top top', scrub: true } });
    });
  }, { scope: root });

  return (
    <section className="stack" ref={root} aria-label="Selected work">
      <div className="wrap stack-head">
        <p className="eyebrow mono">Selected work</p>
        <h2 className="display-2">Cars and builds.</h2>
      </div>
      {FEATURED.map((p, i) => {
        const [w, h] = imgSize(p.image);
        return (
          <article className="stack-card" key={p.id}>
            <Link to={`/work#${p.id}`} className="stack-inner">
              <img src={imgSrc(p.image)} srcSet={imgSet(p.image)} sizes="100vw" width={w} height={h} alt={p.alt} loading="lazy" decoding="async" />
              <div className="stack-copy wrap">
                <span className="mono red">{String(i + 1).padStart(2, '0')} / {String(FEATURED.length).padStart(2, '0')} · {p.tag}</span>
                <h3 className="display-3">{p.title}</h3>
                <p>{p.text}</p>
                <span className="mono stack-link">View project →</span>
              </div>
            </Link>
          </article>
        );
      })}
      <div className="wrap stack-foot"><Link className="btn btn-ghost" to="/work">All work <span aria-hidden>→</span></Link></div>
    </section>
  );
}

export default function Home() {
  return (
    <>
      <ScrollStory />

      <section className="home-shop wrap">
        <div className="hs-copy">
          <p className="eyebrow mono">Markov Auto</p>
          <h2 className="display-2">Mechanical Repair Shop.</h2>
          <ScrubText className="big-copy" text="We specialize in enthusiast cars and modified cars. We also provide regular service, repairs, replacement work, and diagnostics." />
          <div className="actions"><Link className="btn btn-red" to="/contact">Schedule Service <span aria-hidden>→</span></Link><Link className="btn btn-ghost" to="/contact">Contact</Link></div>
        </div>
        <ClipImage name="miata-turbo-hood" alt="Blue Mazda Miata with the hood open in the workshop, turbo engine exposed" className="tall" caption="On the floor · Mazda Miata turbo" />
      </section>

      <Steps />
      <ProjectStack />
    </>
  );
}
