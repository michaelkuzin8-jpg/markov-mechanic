import { Link } from 'react-router';
import PageHero from '../components/PageHero';
import ClipImage from '../components/ClipImage';
import { HorizontalGallery, KineticRows, ScrubText, Steps } from '../components/ScrollFx';
import { PROJECTS, WORKSHOP } from '../data/site';

const GALLERY = ['blue-miata-turbo', 'miata-engine-bay', 'garage-miata', 'red-na-miata', 'classic-corvette']
  .map((id) => PROJECTS.find((p) => p.id === id)!)
  .map((p) => ({ image: p.image, title: p.title, text: p.text, alt: p.alt }));

export default function Workshop() {
  return (
    <>
      <PageHero eyebrow="Workshop" lines={['Springfield,', 'Virginia.']} image="miata-garage" index="03" />

      <section className="workshop-intro wrap">
        <div className="wi-label"><p className="eyebrow mono">Our Workshop.</p></div>
        <div className="wi-copy">
          <ScrubText text={WORKSHOP.p1} className="big-copy" />
          <ScrubText text={WORKSHOP.p2} className="big-copy dim" />
          <div className="actions"><Link className="btn btn-red" to="/work">Go to the Work Page <span aria-hidden>→</span></Link><Link className="btn btn-ghost" to="/contact">Schedule Service</Link></div>
        </div>
      </section>

      <KineticRows items={WORKSHOP.specialties} />

      <section className="split-feature wrap">
        <ClipImage name="workshop-miata" alt="Blue Mazda Miata with its hood up on the workshop floor, surrounded by tools and tires" />
        <div>
          <p className="eyebrow mono">Specialists</p>
          <h2 className="display-3">Enthusiast cars, modified cars, custom and DIY builds.</h2>
          <p className="lead" style={{ marginTop: 18 }}>We also service and maintain regular cars.</p>
        </div>
      </section>

      <HorizontalGallery items={GALLERY} />
      <Steps />
    </>
  );
}
