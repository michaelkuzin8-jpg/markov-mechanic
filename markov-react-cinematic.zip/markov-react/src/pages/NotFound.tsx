import { Link } from 'react-router';

export default function NotFound() {
  return (
    <section className="pagehero wrap" style={{ minHeight: '80vh' }}>
      <p className="eyebrow mono">404</p>
      <h1 className="display">Wrong turn.</h1>
      <p className="lead">That page doesn’t exist.</p>
      <div className="actions"><Link className="btn btn-red" to="/">Back to Home</Link></div>
    </section>
  );
}
