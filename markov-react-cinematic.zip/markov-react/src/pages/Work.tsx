import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router';
import { AnimatePresence, LayoutGroup, motion, useMotionValue, useSpring } from 'motion/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import PageHero from '../components/PageHero';
import { RevealChars } from '../components/Split';
import { PROJECTS, type Project } from '../data/site';
import { imgSet, imgSrc, imgSize, prefersReducedMotion } from '../lib/hooks';

gsap.registerPlugin(ScrollTrigger);
const EASE = [0.16, 1, 0.3, 1] as const;

function Card({ p, i, onOpen }: { p: Project; i: number; onOpen: (id: string) => void }) {
  const [w, h] = imgSize(p.image);
  return (
    <motion.button
      layout
      type="button"
      className={`work-card wc-${i % 6}`}
      id={p.id}
      onClick={() => onOpen(p.id)}
      aria-haspopup="dialog"
      transition={{ layout: { duration: 0.8, ease: EASE } }}
    >
      <motion.span className="wc-media" layoutId={`work-img-${p.id}`}>
        <img className="wc-img" src={imgSrc(p.image)} srcSet={imgSet(p.image)} sizes="(max-width: 820px) 100vw, 50vw" width={w} height={h} alt={p.alt} loading="lazy" decoding="async" />
        <span className="wc-view mono" aria-hidden>View</span>
      </motion.span>
      <span className="wc-meta">
        <span className="mono red">{String(i + 1).padStart(2, '0')} · {p.tag}</span>
        <span className="wc-title">{p.title}</span>
      </span>
    </motion.button>
  );
}

function IndexRow({ p, i, onOpen, onHover }: { p: Project; i: number; onOpen: (id: string) => void; onHover: (id: string | null) => void }) {
  return (
    <motion.button layout type="button" className="wi-row" id={p.id} onClick={() => onOpen(p.id)} onPointerEnter={() => onHover(p.id)} onPointerLeave={() => onHover(null)} aria-haspopup="dialog" transition={{ layout: { duration: 0.8, ease: EASE } }}>
      <span className="mono">{String(i + 1).padStart(2, '0')}</span>
      <span className="wi-title">{p.title}</span>
      <span className="mono wi-tag">{p.tag}</span>
      <motion.span className="wi-thumb" layoutId={`work-img-${p.id}`}><img src={imgSrc(`${p.image}-800`)} alt="" loading="lazy" /></motion.span>
    </motion.button>
  );
}

function Viewer({ id, onClose, onGo }: { id: string; onClose: () => void; onGo: (id: string) => void }) {
  const i = PROJECTS.findIndex((p) => p.id === id);
  const p = PROJECTS[i];
  const [start] = useState(id);
  const [dir, setDir] = useState(1);
  const closeBtn = useRef<HTMLButtonElement>(null);
  const go = useCallback((d: number) => { setDir(d); onGo(PROJECTS[(i + d + PROJECTS.length) % PROJECTS.length].id); }, [i, onGo]);

  useEffect(() => {
    document.documentElement.classList.add('menu-lock');
    closeBtn.current?.focus();
    return () => document.documentElement.classList.remove('menu-lock');
  }, []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'ArrowLeft') go(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [go, onClose]);

  const [w, h] = imgSize(p.image);
  return (
    <motion.div className="viewer" role="dialog" aria-modal="true" aria-label={p.title}
      initial={{ backgroundColor: 'rgba(5,5,5,0)' }} animate={{ backgroundColor: 'rgba(5,5,5,0.97)' }} exit={{ backgroundColor: 'rgba(5,5,5,0)', transition: { delay: 0.2 } }}>
      <motion.div className="viewer-stage" layoutId={`work-img-${start}`} transition={{ duration: 0.85, ease: EASE }}>
        <AnimatePresence initial={false} custom={dir}>
          <motion.img
            key={p.id}
            custom={dir}
            src={imgSrc(p.image)} srcSet={imgSet(p.image)} sizes="100vw" width={w} height={h} alt={p.alt}
            variants={{
              enter: (d: number) => ({ clipPath: d > 0 ? 'inset(0 0 0 100%)' : 'inset(0 100% 0 0)', scale: 1.15 }),
              center: { clipPath: 'inset(0 0% 0 0%)', scale: 1, transition: { duration: 1, ease: [0.76, 0, 0.24, 1] } },
              exit: { opacity: 1, transition: { duration: 1 } },
            }}
            initial="enter" animate="center" exit="exit"
            drag="x" dragConstraints={{ left: 0, right: 0 }} dragElastic={0.25}
            onDragEnd={(_, info) => { if (info.offset.x < -80) go(1); else if (info.offset.x > 80) go(-1); }}
          />
        </AnimatePresence>
      </motion.div>

      <div className="viewer-ui">
        <AnimatePresence mode="wait">
          <motion.div key={p.id} className="viewer-copy" exit={{ opacity: 0, transition: { duration: 0.2 } }}>
            <p className="mono red">{p.tag}</p>
            <RevealChars as="h2" text={p.title} className="display-3" delay={0.2} />
            <motion.p initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.5, duration: 0.7 } }}>{p.text}</motion.p>
          </motion.div>
        </AnimatePresence>
        <div className="viewer-ctrl">
          <span className="mono viewer-count"><b>{String(i + 1).padStart(2, '0')}</b> / {String(PROJECTS.length).padStart(2, '0')}</span>
          <button type="button" className="round" onClick={() => go(-1)} aria-label="Previous project">←</button>
          <button type="button" className="round" onClick={() => go(1)} aria-label="Next project">→</button>
          <Link className="btn btn-red btn-sm" to="/contact">Schedule Service</Link>
        </div>
      </div>
      <button ref={closeBtn} type="button" className="viewer-close mono" onClick={onClose}>Close ✕</button>
    </motion.div>
  );
}

export default function Work() {
  const [view, setView] = useState<'gallery' | 'index'>('gallery');
  const { hash } = useLocation();
  const navigate = useNavigate();
  const initial = hash && PROJECTS.some((p) => p.id === hash.slice(1)) ? hash.slice(1) : null;
  const [open, setOpen] = useState<string | null>(initial);
  const [hover, setHover] = useState<string | null>(null);
  const grid = useRef<HTMLDivElement>(null);
  const fx = useSpring(useMotionValue(0), { stiffness: 180, damping: 22 });
  const fy = useSpring(useMotionValue(0), { stiffness: 180, damping: 22 });

  const openP = (id: string | null) => {
    setOpen(id);
    navigate({ search: location.search, hash: id ? `#${id}` : '' }, { replace: true, preventScrollReset: true });
  };

  // Cinematic reveal for gallery cards: frames open and photos settle as they enter
  useGSAP(() => {
    if (view !== 'gallery' || prefersReducedMotion()) return;
    gsap.utils.toArray<HTMLElement>('.work-card').forEach((card) => {
      const media = card.querySelector('.wc-media');
      const img = card.querySelector('.wc-img');
      gsap.fromTo(media, { clipPath: 'inset(100% 0% 0% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.3, ease: 'expo.out', scrollTrigger: { trigger: card, start: 'top 88%' } });
      gsap.fromTo(img, { scale: 1.3 }, { scale: 1.08, duration: 1.6, ease: 'expo.out', scrollTrigger: { trigger: card, start: 'top 88%' } });
      gsap.fromTo(img, { yPercent: -4 }, { yPercent: 4, ease: 'none', scrollTrigger: { trigger: card, start: 'top bottom', end: 'bottom top', scrub: true } });
    });
  }, { scope: grid, dependencies: [view], revertOnUpdate: true });

  const hovered = PROJECTS.find((p) => p.id === hover);
  return (
    <>
      <PageHero eyebrow="Work" lines={['Cars and Builds', 'We Have Done.']} image="porsche-cayman" index="04">
        Click on a car to expand.
      </PageHero>

      <section className="work wrap" ref={grid} onPointerMove={(e) => { fx.set(e.clientX); fy.set(e.clientY); }}>
        <div className="work-bar">
          <p className="mono muted">{PROJECTS.length} projects</p>
          <div className="seg" role="tablist" aria-label="Layout">
            {(['gallery', 'index'] as const).map((v) => (
              <button key={v} role="tab" type="button" aria-selected={view === v} className={view === v ? 'on' : ''} onClick={() => setView(v)}>
                {view === v && <motion.i layoutId="seg-ind" className="seg-ind" transition={{ type: 'spring', stiffness: 400, damping: 34 }} />}
                <span className="mono">{v === 'gallery' ? 'Gallery' : 'Index'}</span>
              </button>
            ))}
          </div>
        </div>
        <LayoutGroup>
          <div className={view === 'gallery' ? 'work-gallery' : 'work-index'}>
            {PROJECTS.map((p, i) => view === 'gallery'
              ? <Card key={p.id} p={p} i={i} onOpen={openP} />
              : <IndexRow key={p.id} p={p} i={i} onOpen={openP} onHover={setHover} />)}
          </div>
          <AnimatePresence>
            {open && <Viewer key="viewer" id={open} onClose={() => openP(null)} onGo={(id) => openP(id)} />}
          </AnimatePresence>
        </LayoutGroup>

        <AnimatePresence>
          {view === 'index' && hovered && !open && (
            <motion.div className="cursor-img" style={{ x: fx, y: fy }} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }} aria-hidden>
              <AnimatePresence initial={false}>
                <motion.img key={hovered.id} src={imgSrc(`${hovered.image}-800`)} alt="" initial={{ clipPath: 'inset(100% 0 0 0)' }} animate={{ clipPath: 'inset(0% 0 0 0)', transition: { duration: 0.5, ease: EASE } }} exit={{ opacity: 1, transition: { duration: 0.5 } }} />
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </section>
    </>
  );
}
