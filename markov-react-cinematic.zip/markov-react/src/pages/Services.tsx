import { useState } from 'react';
import { Link, useSearchParams } from 'react-router';
import Explorer from '../components/Explorer';
import ServiceDeck from '../components/ServiceDeck';
import PageHero from '../components/PageHero';
import ClipImage from '../components/ClipImage';
import { SERVICES, type ServiceKey } from '../data/site';

export default function Services() {
  const [params] = useSearchParams();
  const initial = params.get('focus') as ServiceKey | null;
  const [focus, setFocus] = useState<ServiceKey | null>(SERVICES.some((s) => s.key === initial) ? initial : null);

  const explore = (k: ServiceKey) => {
    setFocus(k);
    document.getElementById('explorer')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <>
      <PageHero eyebrow="Markov Auto" lines={['The Services', 'We Offer.']} image="miata-turbo-hood" index="02">
        Five disciplines, all handled in-house. Explore them on the 3D demo car, or open each one below.
      </PageHero>
      <Explorer focus={focus} setFocus={setFocus} />
      <ServiceDeck onExplore={explore} />

      <section className="callout wrap">
        <div className="callout-inner">
          <p className="eyebrow mono">Urgent</p>
          <h2 className="display-2">Need Service Immediately?</h2>
          <p className="lead">Contact us and tell us what is happening with your car.</p>
          <div className="actions"><Link className="btn btn-red" to="/contact">Contact Here <span aria-hidden>→</span></Link></div>
        </div>
      </section>

      <section className="split-feature wrap">
        <div>
          <p className="eyebrow mono">Past work</p>
          <h2 className="display-2">See the Type of Work We Do.</h2>
          <div className="actions"><Link className="btn btn-ghost" to="/work">Work Page <span aria-hidden>→</span></Link></div>
        </div>
        <ClipImage name="miata-engine-bay" alt="Turbocharged Mazda Miata engine bay with copper valve cover and blue silicone hoses" />
      </section>
    </>
  );
}
