import { useState } from 'react';
import { useSearchParams } from 'react-router';
import { AnimatePresence, motion } from 'motion/react';
import { RevealChars } from '../components/Split';
import ClipImage from '../components/ClipImage';
import { BUSINESS, FORM_SERVICES, STEPS } from '../data/site';

/**
 * Submission is only attempted when the site runs on a real host (Netlify Forms picks up the
 * hidden "service-request" form in index.html at deploy time). Local and preview builds never
 * pretend to send: they say plainly that nothing was sent.
 */
const PREVIEW = import.meta.env.VITE_PREVIEW === '1'
  || typeof location === 'undefined'
  || location.protocol === 'file:'
  || ['localhost', '127.0.0.1', '0.0.0.0'].includes(location.hostname);

type Status = { kind: 'idle' | 'sending' | 'sent' | 'error' | 'preview'; msg?: string };

export default function Contact() {
  const [params] = useSearchParams();
  const preset = params.get('service');
  const [emergency, setEmergency] = useState<'No' | 'Yes'>('No');
  const [status, setStatus] = useState<Status>({ kind: 'idle' });

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (!form.reportValidity()) return;
    if (PREVIEW) {
      setStatus({ kind: 'preview', msg: 'Preview only: this form is not connected here, so your request was NOT sent. It sends through Netlify Forms once the site is deployed on Netlify.' });
      return;
    }
    setStatus({ kind: 'sending' });
    try {
      const body = new URLSearchParams(new FormData(form) as unknown as Record<string, string>).toString();
      const res = await fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
      if (!res.ok) throw new Error(String(res.status));
      form.reset();
      setEmergency('No');
      setStatus({ kind: 'sent', msg: 'Thanks, your request was sent. We will get back to you as soon as possible.' });
    } catch {
      setStatus({ kind: 'error', msg: 'Your request could not be sent. Please try again in a moment.' });
    }
  };

  return (
    <>
      <header className="contact-hero wrap">
        <motion.p className="eyebrow mono" initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { delay: 0.4 } }}>Contact</motion.p>
        <h1 className="display">
          <RevealChars text="Tell Us What Your" delay={0.4} />
          <RevealChars text="Car Needs." delay={0.6} className="red" />
        </h1>
        <motion.p className="lead" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0, transition: { delay: 1, duration: 0.8 } }}>
          If you have a car problem or a performance build you want installed, contact us here. If it is an emergency, mark it below. We will get back to you as soon as possible.
        </motion.p>
      </header>

      <section className="contact-x wrap">
        <motion.form
          className="form-x" name="service-request" method="POST" data-netlify="true" netlify-honeypot="bot-field" onSubmit={submit} noValidate={false}
          initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.8, duration: 1, ease: [0.16, 1, 0.3, 1] } }}
        >
          <input type="hidden" name="form-name" value="service-request" />
          <p className="hp"><label>Leave this empty <input name="bot-field" tabIndex={-1} autoComplete="off" /></label></p>

          <div className={`form-status mono ${PREVIEW ? 'warn' : 'ok'}`} role="note">
            <span className="dot" />
            {PREVIEW
              ? 'Submission status: NOT connected in this preview. Nothing you enter here is sent.'
              : 'Submission status: sends via Netlify Forms (form “service-request”).'}
          </div>

          <div className="fgrid">
            <div className="f"><input id="f-name" name="name" placeholder=" " autoComplete="name" required /><label htmlFor="f-name">Name *</label></div>
            <div className="f"><input id="f-phone" name="phone" type="tel" placeholder=" " autoComplete="tel" required /><label htmlFor="f-phone">Phone *</label></div>
            <div className="f full"><input id="f-email" name="email" type="email" placeholder=" " autoComplete="email" required /><label htmlFor="f-email">Email *</label></div>
            <fieldset className="f full emergency">
              <legend>Emergency?</legend>
              <input type="hidden" name="emergency" value={emergency} />
              <div className="seg seg-lg">
                {(['No', 'Yes'] as const).map((v) => (
                  <button key={v} type="button" aria-pressed={emergency === v} className={emergency === v ? `on ${v === 'Yes' ? 'urgent' : ''}` : ''} onClick={() => setEmergency(v)}>
                    {emergency === v && <motion.i layoutId="em-ind" className="seg-ind" transition={{ type: 'spring', stiffness: 400, damping: 34 }} />}
                    <span className="mono">{v}</span>
                  </button>
                ))}
              </div>
            </fieldset>
            <div className="f third"><input id="f-year" name="year" inputMode="numeric" placeholder=" " /><label htmlFor="f-year">Year</label></div>
            <div className="f third"><input id="f-make" name="make" placeholder=" " /><label htmlFor="f-make">Make</label></div>
            <div className="f third"><input id="f-model" name="model" placeholder=" " /><label htmlFor="f-model">Model</label></div>
            <div className="f full select">
              <select id="f-service" name="service" defaultValue={FORM_SERVICES.includes(preset ?? '') ? preset! : FORM_SERVICES[0]}>
                {FORM_SERVICES.map((o) => <option key={o}>{o}</option>)}
              </select>
              <label htmlFor="f-service">Type of Work</label>
            </div>
            <div className="f full"><textarea id="f-details" name="details" placeholder=" " required rows={5} /><label htmlFor="f-details">What is happening with the car? *</label></div>
          </div>

          <button className="btn btn-red send" type="submit" disabled={status.kind === 'sending'}>
            {status.kind === 'sending' ? 'Sending…' : 'Send Request'} <span aria-hidden>→</span>
          </button>
          <AnimatePresence mode="wait">
            {status.msg && (
              <motion.p key={status.kind} className={`form-msg ${status.kind}`} role="status" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                {status.msg}
              </motion.p>
            )}
          </AnimatePresence>
        </motion.form>

        <aside className="contact-aside">
          <div className="next">
            <p className="eyebrow mono">What happens next</p>
            <ol>{STEPS.map((s, i) => <li key={s.title}><span className="mono">0{i + 1}</span><div><strong>{s.title}</strong><p>{s.text}</p></div></li>)}</ol>
          </div>
          <ClipImage name="audi-a5-night" alt="White Audi A5 coupe at night" sizes="(max-width: 900px) 100vw, 38vw" />
          <ClipImage name="porsche-cayman" alt="Red Porsche Cayman S by the coast" sizes="(max-width: 900px) 100vw, 38vw" />
          <p className="mono muted">{BUSINESS.name} · {BUSINESS.location}</p>
        </aside>
      </section>
    </>
  );
}
